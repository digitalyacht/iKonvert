function isHex(str) {
    if (!str || str.length === 0) {
        return false;
    }
    const cleanStr = str.toLowerCase().startsWith('0x') ? str.slice(2) : str;
    const hexPattern = /^[0-9a-f]+$/i;
    return hexPattern.test(cleanStr);
}

function base64ToHex(str) {
    let response = "";
    try {
        const raw = atob(str);
        for (let i = 0; i < raw.length; i++) {
            const hex = raw.charCodeAt(i).toString(16);
            response += (hex.length === 2 ? hex : '0' + hex);
        }
    } catch {
        response = str;
    }

    return response.toUpperCase();
}

function HexToBinary(hexStr) {
    return parseInt(hexStr, 16).toString(2).padStart(hexStr.length * 4, '0');
}
function BinaryToHex(binStr) {
    const hexLength = Math.ceil(binStr.length / 4);
    return parseInt(binStr, 2).toString(16).padStart(hexLength, '0');
}

function decodeHexData(hexData, bitLength, unitScale, unitType) { // only used in archive now

    let response = {};
    let remainingHex = hexData;
    let rawValue = 0;
    let convertedValue = 0;
    let convertedUnits = unitType;
    let bytes = parseInt(bitLength / 8);
    // let bytes = Math.ceil(bitLength / 8); // Math.ceil() may cause errors for decoding
    let hexStr = "";

    if (unitType === "char") {

        let charStr = "";

        for (let i = 0; i < bytes; i++) {
            hexStr += remainingHex.substr(i * 2, 2);
            charStr += String.fromCharCode(parseInt(hexStr, 16));
        }

        response = {
            rawValue: rawValue,
            convertedValue: charStr.trim(),
            convertedUnits: convertedUnits,
            remainingHex: remainingHex.substr(bytes * 2), // recursion
            thisHex: hexStr, // debug
        };
    } else {

        bytes = parseInt(bitLength / 8);
        let byteOverflow = bitLength % 8;

        for (let i = bytes - 1; i >= 0; i--) {
            hexStr += remainingHex.substr(i * 2, 2);
        }

        // handle signed / unsigned int
        const isSignedUnit = unitScale[0] === '-';
        if (isSignedUnit) {
            // signed -> two's complement
            rawValue = parseInt(hexStr, 16);
            const bitLength = hexStr.length * 4;
            if (rawValue >= Math.pow(2, bitLength - 1)) {
                rawValue -= Math.pow(2, bitLength);
            }
        } else {
            // unsigned -> normal
            rawValue = parseInt(hexStr, 16);
        }

        // get what all 1's would look like and compare
        let allOnesStr = (isSignedUnit ? '0' : '1').padEnd(bitLength, '1');
        while (allOnesStr.length % 4 != 0) allOnesStr = '0' + allOnesStr;
        let allOnesVal = parseInt(allOnesStr, 2).toString(16).toUpperCase();
        if (allOnesVal.length % 2 != 0) allOnesVal = '0' + allOnesVal;
        const isAllOnes = allOnesVal == hexStr;

        let isInvalid = true;
        for (let i = 0; i < hexStr.length; i++) {
            if (hexStr[i] !== 'F') {
                isInvalid = false;
                break;
            }
        }

        if (isInvalid || (hexStr[0] === '3' && hexStr.length > 1)) {
            convertedValue = null;
        } else {
            ({ convertedValue, convertedUnits } = handleDataConversion(rawValue, unitScale.replace('-', ''), unitType));
        }

        // remainingHex = remainingHex.substr(bytes * 2);

        response = {
            rawValue: rawValue,
            isAllOnes: isAllOnes,
            convertedValue: convertedValue,
            convertedUnits: convertedUnits,
            remainingHex: remainingHex.substr(bytes * 2),
            thisHex: hexStr, // debug
        };
    }

    return response;
}

function handleDataConversion(rawValue, unitScale, unitType) {
    let convertedUnits = '';
    let convertedValue = rawValue * unitScale;
    switch (unitType) {
        case 'm/s':
            convertedValue = (convertedValue * 1.94384);
            convertedUnits = 'knots';
            break;
        case 'deg K':
            convertedValue = (convertedValue - 273.15);
            convertedUnits = 'deg C';
            break;
        case 'rad':
            convertedValue = (convertedValue * 57.2958);
            convertedUnits = 'deg';
            break;
        case 'rad/s':
            convertedValue = (convertedValue * 3437.75);
            convertedUnits = 'deg/sec';
            break;
        case 'Pa':
            convertedValue = (convertedValue / 100000);
            convertedUnits = 'bar';
            break;
        case 'deg':

            if (convertedValue > 360) {
                convertedValue = 429.4967295 - convertedValue;
            }
            let degrees = parseInt(convertedValue);
            let minutes = Math.abs((convertedValue - degrees) * 60);
            convertedValue = `${degrees}° ${minutes.toFixed(3)}'`;
            break;
        case 's':

            let date = new Date(convertedValue * 1000);
            convertedValue = date.toLocaleTimeString("en-UK");
            break;
        case 'day':

            let dayDate = new Date(86400000 * convertedValue);
            convertedValue = dayDate.toLocaleDateString("en-UK");
            break;
        default:

            break;
    }
    return { convertedValue, convertedUnits };
}

function decodeLittleEndHex(hex, bitLength, offset = 0) {
    bitLength = Number(bitLength);
    const bytes = Uint8Array.from(
        hex.match(/.{1,2}/g).map(b => parseInt(b, 16))
    );
    
    let result = 0n; // Use BigInt
    let byteIndex = Math.floor(offset / 8);
    let bitIndex = offset % 8;
    let bitsRead = 0;
    
    while (bitsRead < bitLength && byteIndex < bytes.length) {
        const currentByte = BigInt(bytes[byteIndex]);
        const bitsAvailable = 8 - bitIndex;
        const bitsToRead = Math.min(bitLength - bitsRead, bitsAvailable);
        const mask = ((1n << BigInt(bitsToRead)) - 1n) << BigInt(bitIndex);
        const extractedBits = (currentByte & mask) >> BigInt(bitIndex);
        result = result | (extractedBits << BigInt(bitsRead));
        
        bitsRead += bitsToRead;
        byteIndex++;
        bitIndex = 0;
    }
    
    const hexString = result.toString(16).padStart(Math.ceil(bitLength / 4), '0');
    return {
        hexValue: hexString,
        offset: offset + Number(bitLength)
    };
}

function decodePgnMessageV2(msg) {

    let response = [];
    const definingEntries = 4;
    const splitMsg = msg.split(',');
    let decodedHex = splitMsg[splitMsg.length - 1];
    if (splitMsg[1] != '126996' && splitMsg[1] != '126998' && !!! isHex(splitMsg[splitMsg.length-1])) decodedHex = base64ToHex(decodedHex); // decode base64 to hex
    // else console.warn('Assuming that we have been given HEX data');
    const pgnNum = Number(splitMsg[1]);
    const fields = getFieldsFromPgn(pgnNum);
    if (fields) {
        let offset = 0;
        const splitFields = fields.split(',');
        const fieldCount = Number(splitFields.shift());
        for (let i = 0; i < fieldCount; i++) {
            const currentBaseIndex = i * definingEntries;
            const bitLen = splitFields[currentBaseIndex];
            const name = splitFields[currentBaseIndex + 1];
            const unitScale = splitFields[currentBaseIndex + 2];
            const unit = splitFields[currentBaseIndex + 3];

            if (unit.toLowerCase() === "char") {

                let hexValue, charStr = "";

                ({ hexValue, offset } = decodeLittleEndHex(decodedHex, bitLen, offset));
                const byteLen = bitLen/8;
                const actualByteLen = hexValue.length / 2; 

                for (let i = 0; i < hexValue.length; i += 2) {
                    const hexByte = hexValue.substring(i, i + 2);
                    if (hexByte.length === 2) {
                        const byteValue = parseInt(hexByte, 16);
                        // Skip null terminators and invalid values
                        if (byteValue !== 0 && !isNaN(byteValue)) {
                            charStr += String.fromCharCode(byteValue);
                        }
                    }
                }
                
                const rawValue = charStr.trim().split("").reverse().join("");
                const bitLength = hexValue.length * 4;
                const isAllOnes = calculateIsAllOnes(false, bitLength, hexValue);

                response.push({
                    rawValue: rawValue,
                    convertedValue: rawValue,
                    convertedUnits: "",
                    isAllOnes,
                    meta: {bitLen, name, multi: unitScale, unit},
                    // thisHex: hexValue, // debug
                });

            } else {

                const isSignedUnit = unitScale[0] === '-';
                let hexValue, convertedValue, convertedUnits, rawValue;

                ({ hexValue, offset } = decodeLittleEndHex(decodedHex, bitLen, offset));
                
                const bitLength = hexValue.length * 4;

                if (isSignedUnit) {
                    // signed -> two's complement
                    rawValue = parseInt(hexValue, 16);
                    if (rawValue >= Math.pow(2, bitLength - 1)) {
                        rawValue -= Math.pow(2, bitLength);
                    }
                } else {
                    // unsigned -> normal
                    rawValue = parseInt(hexValue, 16);
                }

                const isAllOnes = calculateIsAllOnes(isSignedUnit, bitLength, hexValue);

                ({ convertedValue, convertedUnits } = handleDataConversion(rawValue, unitScale.replace('-', ''), unit));

                response.push({
                    rawValue,
                    convertedValue,
                    convertedUnits,
                    isAllOnes,
                    meta: {bitLen, name, multi: unitScale, unit}
                });

            }
        }
    }
    return response;
}

function calculateIsAllOnes(isSignedUnit, bitLength, hexValue){
    // get what all 1's would look like and compare
    let allOnesStr = (isSignedUnit ? '0' : '1').padEnd(bitLength, '1');
    while (allOnesStr.length % 4 != 0) allOnesStr = '0' + allOnesStr;
    let allOnesVal = parseInt(allOnesStr, 2).toString(16);
    if (allOnesVal.length % 2 != 0) allOnesVal = '0' + allOnesVal;
    // make sure we force the same case when testing
    return allOnesVal.toUpperCase() == hexValue.toUpperCase();
}

function decode126996(msg) {
    const regex = /\?ÕÌ_|_Œ‚|[Š�ŽÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÑÒÓÔÕÖØÙÚÛÜÝÞßðÿ_]+/gi;
    const splitMsg = msg.split(',');
    const hx_dat = splitMsg[splitMsg.length - 1];

    const dbVer = (((parseInt((hx_dat[2] + hx_dat[3]), 16) << 8) + (parseInt((hx_dat[0] + hx_dat[1]), 16))) / 1000);
    const prodCode = ((parseInt((hx_dat[6] + hx_dat[7]), 16) << 8) + (parseInt((hx_dat[4] + hx_dat[5]), 16)));

    let tmpbte = "";
    for (let g = 0; g < 32; g++) { if ((hx_dat[2 * g + 8] == '0') && (hx_dat[2 * g + 9] == '0')) break; else tmpbte += String.fromCharCode(parseInt((hx_dat[2 * g + 8] + hx_dat[2 * g + 9]), 16)); }
    const modelId = tmpbte.replace(regex, '').trim();

    tmpbte = "";
    for (let g = 0; g < 32; g++) { if ((hx_dat[2 * g + 72] == '0') && (hx_dat[2 * g + 73] == '0')) break; else tmpbte += String.fromCharCode(parseInt((hx_dat[2 * g + 72] + hx_dat[2 * g + 73]), 16)); }
    const softwareVer = tmpbte.replace(regex, '').trim();

    tmpbte = "";
    for (let g = 0; g < 32; g++) { if ((hx_dat[2 * g + 136] == '0') && (hx_dat[2 * g + 137] == '0')) break; else tmpbte += String.fromCharCode(parseInt((hx_dat[2 * g + 136] + hx_dat[2 * g + 137]), 16)); }
    const modelVer = tmpbte.replace(regex, '').trim();

    tmpbte = "";
    for (let g = 0; g < 32; g++) { if ((hx_dat[2 * g + 200] == '0') && (hx_dat[2 * g + 201] == '0')) break; else tmpbte += String.fromCharCode(parseInt((hx_dat[2 * g + 200] + hx_dat[2 * g + 201]), 16)); }
    const modelSerialCode = tmpbte.replace(regex, '').trim();

    const certLvl = parseInt((hx_dat[264] + hx_dat[265]), 16);
    const loadEquiv = parseInt((hx_dat[267]), 16);

    return { dbVer, prodCode, modelId, softwareVer, modelVer, modelSerialCode, certLvl, loadEquiv }
}

function decode126998(msg) {
    const regex = /\?ÕÌ_|_Œ‚|[Š�ŽÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÑÒÓÔÕÖØÙÚÛÜÝÞßðÿ_]+/gi;
    const splitMsg = msg.split(',');
    const hx_datc = splitMsg[splitMsg.length - 1];

    let c1 = "", c2 = "", c3 = "";

    let len = parseInt((hx_datc[0] + hx_datc[1]), 16);
    if (len > 2) {
        let tmpbtc = "";
        for (let g = 0; g < (len - 2); g++) tmpbtc += String.fromCharCode(parseInt((hx_datc[2 * g + 4] + hx_datc[2 * g + 5]), 16));
        c1 = tmpbtc.replace(regex, '').trim();
    }
    
    let startlen = 2 * len;
    len = parseInt((hx_datc[startlen] + hx_datc[startlen + 1]), 16);
    if (len > 2) {
        tmpbtc = "";
        for (let g = 0; g < (len - 2); g++) tmpbtc += String.fromCharCode(parseInt((hx_datc[2 * g + 4 + startlen] + hx_datc[2 * g + 5 + startlen]), 16));
        c2 = tmpbtc.replace(regex, '').trim();
    }

    startlen += 2 * len;
    len = parseInt((hx_datc[startlen] + hx_datc[startlen + 1]), 16);
    if (len > 2) {
        tmpbtc = "";
        for (let g = 0; g < (len - 2); g++) tmpbtc += String.fromCharCode(parseInt((hx_datc[2 * g + 4 + startlen] + hx_datc[2 * g + 5 + startlen]), 16));
        c3 = tmpbtc.replace(regex, '').trim();
    }

    return [c1, c2, c3];
}
