const propMsgTitle = 'Proprietary message';

function getFieldsFromPgn(pgnNum) {

    // console.warn("NEED TO PROTECT THIS DATA!!!");
    // console.warn("NEED TO PROTECT THIS DATA!!!");
    // console.warn("NEED TO PROTECT THIS DATA!!!");
    // console.warn("NEED TO PROTECT THIS DATA!!!");
    // console.warn("NEED TO PROTECT THIS DATA!!!");

    const conversionIndex = pgn_id.indexOf(Number(pgnNum));
    const fields = pgn_fields[conversionIndex];
    return fields;
}

function getTitleFromPgn(pgnNum) {
    let response = propMsgTitle;
    for (const entry of pgnTitles) {
        const splitEntry = entry.split('-');
        const thisCode = splitEntry.shift();
        if (String(pgnNum) == thisCode) {
            response = splitEntry.join(' - ');
            break;
        }
    }
    return response;
}

function getTxRateFromPgn(pgnNum) {
    let foundIndex = -1;
    let response = 1;
    for (const [entry, index] of pgnTitles) {
        const splitEntry = entry.split('-');
        const thisCode = splitEntry.shift();
        if (String(pgnNum) == thisCode) {
            foundIndex = index;
            break;
        }
    }
    if (foundIndex != -1 && foundIndex < defaultTiming.length) response = defaultTiming[index] === 0 ? 1 : defaultTiming[index]; // if got 0, set to 1
    return response;
}

function getManFromCode(code){
    let response = "Unknown manufacturer";
    for (const entry of manData){
        const splitEntry = entry.split('-');
        const thisCode = splitEntry.shift();
        if (String(code) == thisCode) {
            response = splitEntry.join(' - ');
            break;
        }
    }
    return response;
}

function getKfFromCode(code){
    let response = "Unknown functionality";
    for (const entry of KFData){
        const splitEntry = entry.split('-');
        const thisCode = splitEntry.shift();
        if (String(code) == thisCode) {
            // response = splitEntry.join(' - ');
            response = splitEntry;
            break;
        }
    }
    return response;
}

// incase we add other similar lists
function getThingFromCode(thingArr, code, defaultMsg = "Nothing found") {
    let response = defaultMsg;
    for (const entry of thingArr) {
        const splitEntry = entry.split('-');
        const thisCode = splitEntry.shift();
        if (String(code) == thisCode) {
            response = splitEntry.join(' - ');
            break;
        }
    }
    return response;
}

let pgn_id = [];
let pgn_fields = [];

pgn_id[0] = 0;
pgn_id[1] = 59392;
pgn_id[2] = 59904;
pgn_id[3] = 60160;
pgn_id[4] = 60416;
pgn_id[5] = 60416;
pgn_id[6] = 60416;
pgn_id[7] = 60416;
pgn_id[8] = 60416;
pgn_id[9] = 60928;
pgn_id[10] = 65240;
pgn_id[11] = 126208;
pgn_id[12] = 126208;
pgn_id[13] = 126208;
pgn_id[14] = 126208;
pgn_id[15] = 126208;
pgn_id[16] = 126208;
pgn_id[17] = 126208;
pgn_id[18] = 126464;
pgn_id[19] = 126464;
pgn_id[20] = 126983;
pgn_id[21] = 126984;
pgn_id[22] = 126985;
pgn_id[23] = 126986;
pgn_id[24] = 126987;
pgn_id[25] = 126988;
pgn_id[26] = 126992;
pgn_id[27] = 126993;
pgn_id[28] = 126996;
pgn_id[29] = 126998;
pgn_id[30] = 127233;
pgn_id[31] = 127237;
pgn_id[32] = 127245;
pgn_id[33] = 127250;
pgn_id[34] = 127251;
pgn_id[35] = 127252;
pgn_id[36] = 127257;
pgn_id[37] = 127258;
pgn_id[38] = 127488;
pgn_id[39] = 127489;
pgn_id[40] = 127493;
pgn_id[41] = 127496;
pgn_id[42] = 127497;
pgn_id[43] = 127498;
pgn_id[44] = 127500;
pgn_id[45] = 127501;
pgn_id[46] = 127502;
pgn_id[47] = 127503;
pgn_id[48] = 127504;
pgn_id[49] = 127505;
pgn_id[50] = 127506;
pgn_id[51] = 127507;
pgn_id[52] = 127508;
pgn_id[53] = 127509;
pgn_id[54] = 127510;
pgn_id[55] = 127511;
pgn_id[56] = 127512;
pgn_id[57] = 127513;
pgn_id[58] = 127514;
pgn_id[59] = 127744;
pgn_id[60] = 127745;
pgn_id[61] = 127746;
pgn_id[62] = 127747;
pgn_id[63] = 127748;
pgn_id[64] = 127749;
pgn_id[65] = 127750;
pgn_id[66] = 127751;
pgn_id[67] = 128259;
pgn_id[68] = 128267;
pgn_id[69] = 128275;
pgn_id[70] = 128520;
pgn_id[71] = 129025;
pgn_id[72] = 129026;
pgn_id[73] = 129027;
pgn_id[74] = 129028;
pgn_id[75] = 129029;
pgn_id[76] = 129033;
pgn_id[77] = 129038;
pgn_id[78] = 129039;
pgn_id[79] = 129040;
pgn_id[80] = 129041;
pgn_id[81] = 129044;
pgn_id[82] = 129045;
pgn_id[83] = 129283;
pgn_id[84] = 129284;
pgn_id[85] = 129285;
pgn_id[86] = 129291;
pgn_id[87] = 129301;
pgn_id[88] = 129302;
pgn_id[89] = 129538;
pgn_id[90] = 129539;
pgn_id[91] = 129540;
pgn_id[92] = 129541;
pgn_id[93] = 129542;
pgn_id[94] = 129545;
pgn_id[95] = 129546;
pgn_id[96] = 129547;
pgn_id[97] = 129549;
pgn_id[98] = 129550;
pgn_id[99] = 129551;
pgn_id[100] = 129556;
pgn_id[101] = 129792;
pgn_id[102] = 129793;
pgn_id[103] = 129794;
pgn_id[104] = 129795;
pgn_id[105] = 129796;
pgn_id[106] = 129797;
pgn_id[107] = 129798;
pgn_id[108] = 129799;
pgn_id[109] = 129800;
pgn_id[110] = 129801;
pgn_id[111] = 129802;
pgn_id[112] = 129803;
pgn_id[113] = 129804;
pgn_id[114] = 129805;
pgn_id[115] = 129806;
pgn_id[116] = 129807;
pgn_id[117] = 129808;
pgn_id[118] = 129809;
pgn_id[119] = 129810;
pgn_id[120] = 129811;
pgn_id[121] = 129812;
pgn_id[122] = 129813;
pgn_id[123] = 130052;
pgn_id[124] = 130053;
pgn_id[125] = 130054;
pgn_id[126] = 130060;
pgn_id[127] = 130061;
pgn_id[128] = 130064;
pgn_id[129] = 130065;
pgn_id[130] = 130066;
pgn_id[131] = 130067;
pgn_id[132] = 130068;
pgn_id[133] = 130069;
pgn_id[134] = 130070;
pgn_id[135] = 130071;
pgn_id[136] = 130072;
pgn_id[137] = 130073;
pgn_id[138] = 130074;
pgn_id[139] = 130306;
pgn_id[140] = 130310;
pgn_id[141] = 130311;
pgn_id[142] = 130312;
pgn_id[143] = 130313;
pgn_id[144] = 130314;
pgn_id[145] = 130315;
pgn_id[146] = 130316;
pgn_id[147] = 130320;
pgn_id[148] = 130321;
pgn_id[149] = 130322;
pgn_id[150] = 130323;
pgn_id[151] = 130324;
pgn_id[152] = 130560;
pgn_id[153] = 130567;
pgn_id[154] = 130569;
pgn_id[155] = 130570;
pgn_id[156] = 130571;
pgn_id[157] = 130572;
pgn_id[158] = 130573;
pgn_id[159] = 130574;
pgn_id[160] = 130576;
pgn_id[161] = 130577;
pgn_id[162] = 130578;
pgn_id[163] = 130580;
pgn_id[164] = 130581;
pgn_id[165] = 130582;
pgn_id[166] = 130583;
pgn_id[167] = 130584;
pgn_id[168] = 130585;
pgn_id[169] = 100000;
pgn_id[170] = 128000;
pgn_id[171] = 128006;
pgn_id[172] = 128007;
pgn_id[173] = 128008;
pgn_id[174] = 128538;
pgn_id[175] = 128768;
pgn_id[176] = 128769;
pgn_id[177] = 128776;
pgn_id[178] = 128777;
pgn_id[179] = 128778;
pgn_id[180] = 128780;
pgn_id[181] = 130900;

pgn_fields[0] = "-";
pgn_fields[1] = "4,8,Control_Byte,1,,8,Group_Function_Value,1,,24,NMEA_Reserved,1,,24,PGN_of_Requested_Information,1,,";
pgn_fields[2] = "1,24,PGN_being_requested,1,,";
pgn_fields[3] = "2,8,Sequence_number_of_multi-packet_frame,1,,56,Multi-packet_packetized_data,1,,";
pgn_fields[4] = "5,8,RTS_Group_Function_Code,1,,16,Total_message_size _bytes,1,bit,8,Total_number_of_frames_to_be_transmitted,1,,8,NMEA_Reserved,1,,24,PGN_of_multi-packet_message,1,,";
pgn_fields[5] = "5,8,CTS_Group_Function_Code,1,,8,Number_of_frames_that_can_be_sent,1,,8,Number_of_next_frame_to_be_transmitted,1,,16,NMEA_Reserved,1,,24,PGN_of_multi-packet_message,1,,";
pgn_fields[6] = "5,8,EOM_Group_Function_Code,1,,16,Total_message_size _bytes,1,bit,8,Total_number_of_frames_received,1,,8,NMEA_Reserved,1,,24,PGN_of_multi-packet_message,1,,";
pgn_fields[7] = "5,8,BAM_Group_Function_Code,1,,16,Total_message_size _bytes,1,bit,8,Total_number_of_frames_to_be_transmitted,1,,8,NMEA_Reserved,1,,24,PGN_of_multi-packet_message,1,,";
pgn_fields[8] = "3,8,Abort_Group_Function_Code,1,,32,NMEA_Reserved,1,,24,PGN_of_multi-packet_message,1,,";
pgn_fields[9] = "10,21,Unique_Number_(ISO_Identity_Number),1,,11,Manufacturer_Code,1,,3,Device_Instance_Lower_(ISO_ECU_Instance),1,,5,Device_Instance_Upper_(ISO_Function_Instance),1,,8,Device_Function_(ISO_Function),1,,1,NMEA_Reserved,1,,7,Device_Class,1,,4,System_Instance_(ISO_Device_Class_Instance),1,,3,Industry_Group,1,,1,NMEA_Reserved_(ISO_Self_Configurable),1,,";
pgn_fields[10] = "11,21,Unique_Number_(ISO_Identity_Number),1,,11,Manufacturer_Code,1,,3,Device_Instance_Lower_(ISO_ECU_Instance),1,,5,Device_Instance_Upper_(ISO_Function_Instance),1,,8,Device_Function_(ISO_Function),1,,1,NMEA_Reserved,1,,7,Device_Class,1,,4,System_Instance_(ISO_Device_Class_Instance),1,,3,Industry_Group,1,,1,Reserved_(ISO_Self_Configurable),1,,8,New_Source_Address,1,,";
pgn_fields[11] = "9,8,Request_Group_Function_Code,1,bit,24,Requested_PGN,1,,32,Transmission_interval,0.001,s,16,Transmission_interval_offset,0.01,sec,8,Number_of_Pairs_of_Request_Parameters_to_follow,1,bit,8,Field_number_of_first_requested_parameter,1,bit,0,Value_of_first_requested_parameter,1,,8,Variable_Number_of_fields _Field_number_6_repeated,1,bit,0,Variable_Number_of_fields _Field_number_7_repeated,1,,";
pgn_fields[12] = "9,8,Command_Group_Function_Code,1,bit,24,Commanded_PGN,1,,4,Priority_Setting,1,,4,NMEA_Reserved,1,,8,Number_of_Pairs_of_Commanded_Parameters_to_follow,1,bit,8,Field_number_of_first_commanded_parameter,1,bit,0,Value_of_first_command_parameter,1,,8,Variable_Number_of_fields _Field_number_6_repeated,1,bit,0,Variable_Number_of_fields _Field_number_7_repeated,1,,";
pgn_fields[13] = "7,8,Acknowledgment_Group_Function_Code,1,bit,24,Requested_or_Commanded_PGN_#_being_acknowledged,1,,4,PGN_error_code,1,,4,Transmission_Interval_/_Priority_error_code,1,,8,Number_of_Requested_or_Commanded_Parameters,1,bit,4,First_parameter_error_code,1,,4,Variable_Number_of_fields _Field_number_6_repeated,1,,";
pgn_fields[14] = "14,8,Complex_Request_Group_Function_Code,1,bit,24,PGN_Number,1,,11,Manufacturer's_Code,1,,2,NMEA_Reserved,1,,3,Industry_Group,1,,8,Unique_ID,1,bit,8,Number_of_Selection_Pairs,1,bit,8,Number_of_Parameter_Pairs_to_be_Read,1,bit,8,Field_Number_of_First_Selection_Pair,1,bit,0,Field_Value_of_First_Selection_Pair,1,,8,Variable_Number_of_fields _field_9_repeated,1,bit,0,Variable_Number_of_Fields _field_10_repeated,1,,8,Field_Number_of_First_Parameter_Pair_to_be_Read,1,bit,8,Variable_Number_of_Fields _field_13_repeated,1,bit,";
pgn_fields[15] = "16,8,Complex_Request_Group_Function_Code,1,bit,24,PGN_Number,1,,11,Manufacturer's_Code,1,,2,NMEA_Reserved,1,,3,Industry_Group,1,,8,Unique_ID,1,bit,8,Number_of_Selection_Pairs,1,bit,8,Number_of_Parameter_Pairs_to_be_Read,1,bit,8,Field_Number_of_First_Selection_Pair,1,bit,0,Field_Value_of_First_Selection_Pair,1,,8,Variable_Number_of_fields _field_9_repeated,1,bit,0,Variable_Number_of_Fields _field_10_repeated,1,,8,Field_Number_of_First_Parameter_Pair_to_be_Read,1,bit,0,Field_Value_of_First_Parameter_Pair_to_be_Read,1,,8,Variable_Number_of_Fields _field_13_repeated,1,bit,0,Variable_Number_of_Fields _field_14_repeated,1,,";
pgn_fields[16] = "16,8,Complex_Request_Group_Function_Code,1,bit,24,PGN_Number,1,,11,Manufacturer's_Code,1,,2,NMEA_Reserved,1,,3,Industry_Group,1,,8,Unique_ID,1,bit,8,Number_of_Selection_Pairs,1,bit,8,Number_of_Parameter_Pairs_to_be_Written,1,bit,8,Field_Number_of_First_Selection_Pair,1,bit,0,Field_Value_of_First_Selection_Pair,1,,8,Variable_Number_of_fields _field_9_repeated,1,bit,0,Variable_Number_of_Fields _field_10_repeated,1,,8,Field_Number_of_First_Parameter_Pair_to_be_Written,1,bit,0,Field_Value_of_First_Parameter_Pair_to_be_Written,1,,8,Variable_Number_of_Fields _field_13_repeated,1,bit,0,Variable_Number_of_Fields _field_14_repeated,1,,";
pgn_fields[17] = "16,8,Complex_Request_Group_Function_Code,1,bit,24,PGN_Number,1,,11,Manufacturer's_Code,1,,2,NMEA_Reserved,1,,3,Industry_Group,1,,8,Unique_ID,1,bit,8,Number_of_Selection_Pairs,1,bit,8,Number_of_Parameter_Pairs_to_be_Written,1,bit,8,Field_Number_of_First_Selection_Pair,1,bit,0,Field_Value_of_First_Selection_Pair,1,,8,Variable_Number_of_fields _field_9_repeated,1,bit,0,Variable_Number_of_Fields _field_10_repeated,1,,8,Field_Number_of_First_Parameter_Pair_to_be_Written,1,bit,0,Field_Value_of_First_Parameter_Pair_to_be_Written,1,,8,Variable_Number_of_Fields _field_13_repeated,1,bit,0,Variable_Number_of_Fields _field_14_repeated,1,,";
pgn_fields[18] = "3,8,Transmitted_PGN_Group_Function_Code,1,bit,24,First_PGN_supported,1,,24,Variable_Number_of_fields _Field_number_2_repeated,1,,";
pgn_fields[19] = "3,8,Received_PGN_Group_Function_Code,1,bit,24,First_PGN_supported,1,,24,Variable_Number_of_fields _Field_number_2_repeated,1,,";
pgn_fields[20] = "21,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,1,Temporary_Silence_Status,1,,1,Acknowledge_Status,1,,1,Escalation_Status,1,,1,Temporary_Silence_Support,1,,1,Acknowledge_Support,1,,1,Escalation_Support,1,,2,NMEA_Reserved,1,,64,Acknowledge_Source_Network_ID_NAME,1,bit,4,Trigger_Condition,1,,4,Threshold_Status,1,,8,Alert_Priority,1,bit,8,Alert_State,1,bit,";
pgn_fields[21] = "12,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,64,Acknowledge_Source_Network_ID_NAME,1,bit,2,Response_Command,1,,6,NMEA_Reserved,1,,";
pgn_fields[22] = "12,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,8,Language_ID,1,bit,8,Alert_Text_Description,1,ASCII,8,Alert_Location__Text_Description,1,ASCII,";
pgn_fields[23] = "15,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,2,Alert_Control,1,,2,User_Defined_Alert_Assignment,1,,4,NMEA_Reserved,1,,32,Reactivation_Period,1,sec,32,Temporary_Silence_Period,1,sec,32,Escalation_Period,1,sec,";
pgn_fields[24] = "15,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,8,Total_Number_of_Threshold_Parameters,1,bit,8,Parameter_Number,1,bit,8,Trigger_Method,1,,8,Threshold_Data_Format,1,bit,0,Threshold_Level,1,,0,Fields_11_to_14_Repeat_as_necessary,1,,";
pgn_fields[25] = "14,4,Alert_Type,1,,4,Alert_Category,1,,8,Alert_System,1,bit,8,Alert_Sub-System,1,bit,16,Alert_ID,1,bit,64,Data_Source_Network_ID_NAME,1,bit,8,Data_Source_Instance,1,,8,Data_Source_Index_/_Source,1,,8,Alert_Occurrence_Number,1,bit,8,Total_Number_of_Value_Parameters,1,bit,8,Value_Parameter_Number,1,bit,8,Value_Data_Format,1,bit,0,Value_Data,1,,0,Fields_11_to_13_Repeat_as_necessary,1,,";
pgn_fields[26] = "5,8,Sequence_ID,1,bit,4,Source,1,,4,NMEA_Reserved,1,,16,Date,1,day,32,Time,0.0001,s,";
pgn_fields[27] = "6,16,Update_Rate,0.001,sec.,8,Heartbeat_Sequence_Counter,1,bit,2,Class_1_CAN_Controller_State,1,,2,Class_2_Second_CAN_Controller_State,1,,2,Equipment_Status,1,,34,NMEA_Reserved,1,,";

// 126996
// pgn_fields[28] = "8,16,NMEA_Network_Message_Database_Version,1,bit,16,NMEA_Manufacturer's_Product_Code,1,bit,480,Manufacturer's_Model_ID,1,char,480,Manufacturer's_Software_Version_Code,1,char,480,Manufacturer's_Model_Version,1,char,480,Manufacturer's_Model_Serial_Code,1,char,8,NMEA_2000_Certification_Level,1,bit,8,Load_Equivalency,1,bit,";
pgn_fields[28] = "8,16,NMEA_Network_Message_Database_Version,1,bit,16,NMEA_Manufacturer's_Product_Code,1,bit,256,Manufacturer's_Model_ID,1,char,480,Manufacturer's_Software_Version_Code,1,char,480,Manufacturer's_Model_Version,1,char,480,Manufacturer's_Model_Serial_Code,1,char,8,NMEA_2000_Certification_Level,1,bit,8,Load_Equivalency,1,bit,";
pgn_fields[29] = "3,8,Installation_Description _Field_1,1,ASCII,8,Installation_Description _Field_2,1,ASCII,8,Manufacturer_Information _Field_3,1,ASCII,";

pgn_fields[30] = "18,8,Sequence_ID,1,bit,32,MOB_Emitter_ID,1,bit,3,Man_Overboard_(MOB)_Status,1,,5,NMEA_Reserved,1,,32,UTC_Time_of_MOB_Activation,0.0001,s,3,Position_Source,1,,5,NMEA_Reserved,1,,16,UTC_Date_of_Position,1,day,32,UTC_Time_of_Position,0.0001,s,32,Latitude,0.0000001,deg,32,Longitude,0.0000001,deg,2,Course_over_ground_Reference,1,,6,NMEA_Reserved,1,,16,Course_over_ground,0.0001,rad,16,Speed_over_ground,0.01,m/s,32,MMSI_of_vessel_of_Origin,1,bit,3,MOB_Emitter_Battery_Status,1,,5,NMEA_Reserved,1,,";
pgn_fields[31] = "18,2,Rudder_Limit_Exceeded,1,,2,Off-Heading_Limit_Exceeded,1,,2,Off-Track_Limit_Exceeded,1,,2,Override,1,,3,Steering_Mode,1,,3,Turn_Mode,1,,2,Heading_Reference,1,,5,NMEA_Reserved,1,,3,Commanded_Rudder_Direction,1,,16,Commanded_Rudder_Angle,-0.0001,rad,16,Heading-To-Steer_(Course),0.0001,rad,16,Track,0.0001,rad,16,Rudder_Limit,0.0001,rad,16,Off-Heading_Limit,0.0001,rad,16,Radius_of_Turn_Order,-1,m,16,Rate_of_Turn_Order,-3.125E-05,rad/s,16,Off-Track_Limit,-1,m,16,Vessel_Heading,0.0001,rad,";
pgn_fields[32] = "6,8,Rudder_Instance,1,,3,Direction_Order,1,,5,NMEA_Reserved,1,,16,Angle_Order,-0.0001,rad,16,Position,-0.0001,rad,16,NMEA_Reserved,1,,";
pgn_fields[33] = "6,8,Sequence_ID,1,bit,16,Heading_Sensor_Reading,0.0001,rad,16,Deviation,-0.0001,rad,16,Variation,-0.0001,rad,2,Heading_Sensor_Reference,1,,6,NMEA_Reserved,1,,";
pgn_fields[34] = "3,8,Sequence_ID,1,bit,32,Rate_of_Turn,-3.125E-08,rad/s,24,NMEA_Reserved,1,,";
pgn_fields[35] = "5,8,Sequence_ID,1,bit,16,Heave,-0.01,m,16,Delay,0.01,sec,4,Delay_Source,1,,20,NMEA_Reserved,1,,";
pgn_fields[36] = "5,8,Sequence_ID,1,bit,16,Yaw,-0.0001,rad,16,Pitch,-0.0001,rad,16,Roll,-0.0001,rad,8,NMEA_Reserved,1,,";
pgn_fields[37] = "6,8,Sequence_ID,1,bit,4,Variation_Source,1,,4,NMEA_Reserved,1,,16,Age_of_Service_(Date),1,day,16,Variation,-0.0001,rad,16,NMEA_Reserved,1,,";
pgn_fields[38] = "5,8,Engine_Instance,1,,16,Engine_Speed,0.25,RPM,16,Engine_Boost_Pressure,100,Pa,8,Engine_tilt/trim,-1,%,16,NMEA_Reserved,1,,";
pgn_fields[39] = "14,8,Engine_instance,1,,16,Engine_oil_pressure,100,Pa,16,Engine_oil_temp.,0.1,deg K,16,Engine_temp.,0.01,deg K,16,Alternator_potential,-0.01,V,16,Fuel_rate,-0.0001,cu-m/hr,32,Total_engine_hours,1,sec,16,Engine_coolant_pressure,100,Pa,16,Fuel_Pressure,1000,Pa,8,Not_Available,1,,16,Engine_Discrete_Status_1,1,,16,Engine_Discrete_Status_2,1,,8,Percent_Engine_Load,-1,%,8,Percent_Engine_Torque,-1,%,";
pgn_fields[40] = "7,8,Transmission_instance,1,,2,Transmission_Gear,1,,6,NMEA_Reserved,1,,16,Transmission_oil_pressure,100,Pa,16,Transmission_oil_temperature,0.1,deg K,8,Transmission_Discrete_Status,1,,8,NMEA_Reserved,1,,";
pgn_fields[41] = "4,32,Time_to_Empty,0.001,s,32,Distance_to_Empty_/Fuel_Range,0.01,m,16,Estimated_Fuel__Remaining,0.001,cu m,32,Trip__Run_Time,0.001,s,";
pgn_fields[42] = "5,8,Engine_instance,1,,16,Trip_fuel_used,0.001,cu m,16,Fuel_Rate _Average,-0.0001,cu-m/hr,16,Fuel_Rate _Economy,-0.0001,cu-m/hr,16,Instantaneous_Fuel_Economy,-0.0001,cu-m/hr,";
pgn_fields[43] = "4,8,Engine_instance,1,,16,Rated_engine_speed,0.25,RPM,8,VIN,1,ASCII,8,Software_ID,1,ASCII,";
pgn_fields[44] = "8,8,Sequence_ID,1,bit,8,Connection_ID,1,bit,8,State,1,,16,Status,1,,3,Operational_Status_&_Control,1,,8,PWM_Duty_Cycle,1,%,8,TimeON,1,seconds,8,TimeOFF,1,seconds,";
pgn_fields[45] = "29,8,Binary_Device_Bank_Instance,1,bit,2,Status_1,1,,2,Status_2,1,,2,Status_3,1,,2,Status_4,1,,2,Status_5,1,,2,Status_6,1,,2,Status_7,1,,2,Status_8,1,,2,Status_9,1,,2,Status_10,1,,2,Status_11,1,,2,Status_12,1,,2,Status_13,1,,2,Status_14,1,,2,Status_15,1,,2,Status_16,1,,2,Status_17,1,,2,Status_18,1,,2,Status_19,1,,2,Status_20,1,,2,Status_21,1,,2,Status_22,1,,2,Status_23,1,,2,Status_24,1,,2,Status_25,1,,2,Status_26,1,,2,Status_27,1,,2,Status_28,1,,";
pgn_fields[46] = "29,8,Switch_Bank_Instance,1,bit,2,Switch_1,1,,2,Switch_2,1,,2,Switch_3,1,,2,Switch_4,1,,2,Switch_5,1,,2,Switch_6,1,,2,Switch_7,1,,2,Switch_8,1,,2,Switch_9,1,,2,Switch_10,1,,2,Switch_11,1,,2,Switch_12,1,,2,Switch_13,1,,2,Switch_14,1,,2,Switch_15,1,,2,Switch_16,1,,2,Switch_17,1,,2,Switch_18,1,,2,Switch_19,1,,2,Switch_20,1,,2,Switch_21,1,,2,Switch_22,1,,2,Switch_23,1,,2,Switch_24,1,,2,Switch_25,1,,2,Switch_26,1,,2,Switch_27,1,,2,Switch_28,1,,";
pgn_fields[47] = "12,8,AC_Instance,1,bit,8,Number_of_Lines,1,bit,2,Line,1,,2,Acceptability,1,,4,NMEA_Reserved,1,,16,Voltage,0.01,V,16,Current,0.1,A,16,Frequency,0.01,Hz,16,Breaker_Size,0.1,A,32,Real_Power,1,W,32,Reactive_Power,1,VAR,8,Power_Factor,-0.01,,";
pgn_fields[48] = "12,8,AC_Instance,1,bit,8,Number_of_lines,1,bit,2,Line,1,,3,Waveform,1,,3,NMEA_Reserved,1,,16,Voltage,0.01,V,16,Current,0.1,A,16,Frequency,0.01,Hz,16,Breaker_Size,0.1,A,32,Real_Power,1,W,32,Reactive_Power,1,VAR,8,Power_Factor,-0.01,,";
pgn_fields[49] = "5,4,Fluid_Instance,1,,4,Fluid_Type,1,,16,Fluid_Level,0.004,%,32,Tank_Capacity,0.0001,cu m,8,NMEA_Reserved,1,,";
pgn_fields[50] = "8,8,Sequence_ID,1,bit,8,DC_Instance,1,bit,8,DC_Type,1,,8,State_of_Charge,1,%,8,State_of_Health,1,%,16,Time_Remaining,1,minute,16,Ripple_Voltage,0.001,V,16,Amp_Hours,1,AH,";
pgn_fields[51] = "8,8,Charger_Instance,1,bit,8,Battery_Instance,1,bit,4,Operating_State,1,,4,Charge_Mode,1,,2,Charger_Enable/Disable,1,,2,Equalization_Pending,1,,4,NMEA_Reserved,1,,16,Equalization_Time_Remaining,1,minute,";
pgn_fields[52] = "5,8,Battery_Instance,1,bit,16,Battery_Voltage,0.01,V,16,Battery_Current,-0.1,A,16,Battery_Case_Temperature,0.01,deg K,8,Sequence_ID,1,bit,";
pgn_fields[53] = "6,8,Inverter_Instance,1,bit,8,AC_Instance,1,bit,8,DC_Instance,1,bit,4,Operating_State,1,,2,Inverter_Enable/Disable,1,,2,NMEA_Reserved,1,,";
pgn_fields[54] = "11,8,Charger_Instance,1,bit,8,Battery_Instance,1,bit,2,Charger_Enable/Disable,1,,6,NMEA_Reserved,1,,8,Charge_Current_Limit,1,%,4,Charging_Algorithm,1,,4,Charger_Mode,1,,4,Estimated_Battery_Temp_-_When_No_Sensor_Present,1,,2,Equalize_One_Time_Enable/Disable,1,,2,Over_Charge_Enable/Disable,1,,16,Equalize_Time,1,minute,";
pgn_fields[55] = "8,8,Inverter_Instance,1,bit,8,AC_Instance,1,bit,8,DC_Instance,1,bit,2,Inverter_Enable/Disable,1,,4,Inverter_Mode,1,,2,Load_Sense_Enable/Disable,1,,16,Load_Sense_Power_Threshold,1,W,16,Load_Sense_Interval,0.01,sec,";
pgn_fields[56] = "4,8,AGS_Instance,1,bit,8,Generator_Instance,1,bit,4,AGS_Mode,1,,44,NMEA_Reserved,1,,";
pgn_fields[57] = "10,8,Battery_Instance,1,bit,4,Battery_Type,1,,2,Supports_Equalization,1,,2,NMEA_Reserved,1,,4,Nominal_Voltage,1,,4,Battery_Chemistry,1,,16,Battery_Capacity,3600,C,8,Battery_Temperature_Coefficient,-1,%,8,Peukert_Exponent,0.002,,8,Charge_Efficiency_Factor,-1,%,";
pgn_fields[58] = "6,8,AGS_Instance,1,bit,8,Generator_Instance,1,bit,4,AGS_Operating_State,1,,4,Generator_State,1,,8,Generator_On_Reason,1,,8,Generator_Off_Reason,1,,";
pgn_fields[59] = "4,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Current,0.1,A,32,Power,-1,W,";
pgn_fields[60] = "4,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Current,0.1,A,32,Power,-1,W,";
pgn_fields[61] = "4,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Current,0.1,A,32,Power,-1,W,";
pgn_fields[62] = "5,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Voltage_Line_to_Neutral,0.1,V,16,AC_RMS_Voltage_Line_to_Line,0.1,V,16,AC_Frequency,1,Hz,";
pgn_fields[63] = "5,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Voltage_Line_to_Neutral,0.1,V,16,AC_RMS_Voltage_Line_to_Line,0.1,V,16,AC_Frequency,1,Hz,";
pgn_fields[64] = "5,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,AC_RMS_Voltage_Line_to_Neutral,0.1,V,16,AC_RMS_Voltage_Line_to_Line,0.1,V,16,AC_Frequency,1,Hz,";
pgn_fields[65] = "8,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,8,Operating_State,1,,2,Temperature_State,1,,2,Overload_State,1,,2,Low_DC_Voltage_State,1,,2,Ripple_State,1,,32,NMEA_Reserved,1,,";
pgn_fields[66] = "5,8,Sequence_ID,1,bit,8,Connection_Number,1,bit,16,DC_Voltage,0.1,V,24,DC_Current,0.1,A,16,NMEA_Reserved,1,,";
pgn_fields[67] = "6,8,Sequence_ID,1,bit,16,Speed_Water_Referenced,0.01,m/s,16,Speed_Ground_Referenced,0.01,m/s,8,Speed_Water_Referenced_Type,1,,4,Speed_Direction,1,,12,NMEA_Reserved,1,,";
pgn_fields[68] = "4,8,Sequence_ID,1,bit,32,Water_Depth_Transducer,0.01,m,16,Offset,-0.001,m,8,Maximum_Depth_Range,10,m,";
pgn_fields[69] = "4,16,Measurement_Date,1,day,32,Measurement_Time,0.0001,s,32,Total_Cumulative_Distance,1,m,32,Distance_Since_Last_Reset,1,m,";
pgn_fields[70] = "14,8,Sequence_ID,1,bit,16,Target_ID_#,1,bit,4,Track_Status,1,,2,Bearing_Reference,1,,2,NMEA_Reserved,1,,16,Bearing,0.0001,rad,32,Distance,-0.01,m,16,Course,0.0001,rad,16,Speed,0.01,m/s,32,CPA,-0.01,m,32,TCPA,-0.001,s,32,UTC_of_Fix,0.0001,s,8,Name,1,ASCII,2,Reference_Target,1,,";
pgn_fields[71] = "2,32,Latitude,0.0000001,deg,32,Longitude,0.0000001,deg,";
pgn_fields[72] = "6,8,Sequence_ID,1,bit,2,COG_Reference,1,,6,NMEA_Reserved,1,,16,Course_Over_Ground,0.0001,rad,16,Speed_Over_Ground,0.01,m/s,16,NMEA_Reserved,1,,";
pgn_fields[73] = "4,8,Sequence_ID,1,bit,8,Time_Delta,0.005,sec,24,Latitude_Delta,0.00001,sec,24,Longitude_Delta,0.00001,sec,";
pgn_fields[74] = "7,8,Sequence_ID,1,bit,8,Time_Delta,0.005,sec,4,GNSS_Quality,1,,2,Direction,1,,2,NMEA_Reserved,1,,16,Course_Over_Ground,0.0001,rad,24,Altitude_Delta,-0.001,m,";
pgn_fields[75] = "21,8,Sequence_ID,1,bit,16,Position_date,1,day,32,Position_time,0.0001,s,64,Latitude,0.0000000000000001,deg,64,Longitude,0.0000000000000001,deg,64,Altitude,0.000001,m,4,Type_of_System,1,,4,Method _GNSS,1,,2,Integrity,1,,6,NMEA_Reserved,1,,8,Number_of_SVs,1,bit,16,HDOP,-0.01,,16,PDOP,-0.01,,32,Geoidal_Separation,-0.01,m,8,Number_of_Reference_Stations,1,bit,4,Reference_Station_Type1,1,,12,Reference_Station_ID1,1,,16,Age_of_DGNSS_Corrections_1,0.01,sec,4,Reference_Station_Type_n,1,,12,Reference_Station_ID_n,1,,16,Age_of_DGNSS_Reference_Station_n,0.01,sec,";
pgn_fields[76] = "3,16,Date,1,day,32,Time,0.0001,s,16,Local_Offset _Minutes,-10,minute,";
pgn_fields[77] = "20,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,RAIM-flag,1,,6,Time_Stamp,1,,16,COG,0.0001,rad,16,SOG,0.01,m/s,19,Communication_State,1,,5,AIS_Transceiver_Information,1,,16,True_Heading,0.0001,rad,16,Rate_of_Turn,-3.125E-05,rad/s,4,Navigational_Status,1,,2,Special_Maneuver_Indicator,1,,2,NMEA_Reserved,1,,3,AIS_Spare,1,,5,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[78] = "24,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,RAIM-flag,1,,6,Time_Stamp,1,,16,COG,0.0001,rad,16,SOG,0.01,m/s,19,Communication_State,1,,5,AIS_Transceiver_Information,1,,16,True_Heading,0.0001,rad,8,Reserved_for_Regional_Applications,1,,2,Reserved_for_Regional_Applications,1,,1,Class_B_unit_flag,1,,1,Class_B_Display_Flag,1,,1,Class_B_DSC_Flag,1,,1,Class_B_Band_Flag,1,,1,Class_B_Msg_22_Flag,1,,1,Mode_Flag,1,,1,Communication_State_Selector_Flag,1,,7,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[79] = "28,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,RAIM-flag,1,,6,Time_Stamp,1,,16,COG,0.0001,rad,16,SOG,0.01,m/s,8,Reserved_for_Regional_Applications,1,,4,Reserved_for_Regional_Applications,1,,4,NMEA_Reserved,1,,8,Ship/Cargo_Type,1,,16,True_Heading,0.0001,rad,4,NMEA_Reserved,1,,4,Type_of_Electronic_Positioning_Device,1,,16,Ship_Length,0.1,m,16,Ship_Beam,0.1,m,16,Position_Reference_Point_from_Starboard,0.1,m,16,Position_Reference_Point_aft_of_Ship's_Bow,0.1,m,160,Name,1,char,1,Data_Terminal_Equipment_(DTE),1,,1,Mode_Flag,1,,4,AIS_Spare,1,,5,AIS_Transceiver_Information,1,,5,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[80] = "23,6,Message_ID,1,,2,Repeat_Indicator,1,,32,ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,RAIM_Flag,1,,6,Time_Stamp,1,,16,AtoN_Structure_Length/Diameter,0.1,m,16,AtoN_Structure_Beam/Diameter,0.1,m,16,Position_Reference_Point_from_Starboard_Structure_Edge/Radius,0.1,m,16,Position_Reference_Point_from_True_North_facing_Structure_Edge/Radius,0.1,m,5,Aid_to_Navigation_(AtoN)_Type,1,,1,Off_Position_Indicator,1,,1,Virtual_AtoN_Flag,1,,1,Assigned_Mode_Flag,1,,1,AIS_Spare,1,,4,Electronic_Fixing_Position_Fixing_Device_Type,1,,3,NMEA_Reserved,1,,8,AtoN_Status,1,,5,AIS_Transceiver_Information,1,,3,NMEA_Reserved,1,,8,Aid_to_Navigation_(AtoN)_Name,1,ASCII,";
pgn_fields[81] = "5,32,Local_Datum,1,char,32,Delta_Latitude,0.0000001,deg,32,Delta_Longitude,0.0000001,deg,32,Delta_Altitude,-0.01,m,32,Reference_Datum,1,char,";
pgn_fields[82] = "10,32,Delta_X,-0.01,m,32,Delta_Y,-0.01,m,32,Delta_Z,-0.01,m,32,Rotation_in_X,1,floats  radian,32,Rotation_in_Y,1,floats  radian,32,Rotation_in_Z,1,floats  radian,32,Scale,1,,32,Ellipsoid_Semi-major_Axis,-0.01,m,32,Ellipsoid_Flattening_Inverse,1,,32,Datum_Name,1,char,";
pgn_fields[83] = "6,8,Sequence_ID,1,bit,4,XTE_Mode,1,,2,NMEA_Reserved,1,,2,Navigation_Terminated,1,,32,XTE,-0.01,m,16,NMEA_Reserved,1,,";
pgn_fields[84] = "15,8,Sequence_ID,1,bit,32,Distance_to_Destination_Waypoint,0.01,m,2,Course/Bearing_Ref.,1,,2,Perpendicular_Crossed,1,,2,Arrival_Circle_Entered,1,,2,Calculation_Type,1,,32,ETA_Time,0.0001,s,16,ETA_Date,1,day,16,Bearing _Origin_To_Destination_Waypoint,0.0001,rad,16,Bearing _Position_To_Destination_Waypoint,0.0001,rad,32,Origin_Waypoint_Number,1,bit,32,Destination_Waypoint_Number,1,bit,32,Destination_Wpt_Latitude,0.0000001,deg,32,Destination_Wpt_Longitude,0.0000001,deg,16,Waypoint_Closing_Velocity,-0.01,m/s,";
pgn_fields[85] = "14,16,Start_RPS#,1,bit,16,nItems,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,3,Navigation_direction_in_route,1,,2,Supplementary_Route/WP_data_available,1,,3,NMEA_Reserved,1,,8,Route_Name,1,ASCII,8,NMEA_Reserved,1,,16,WPID,1,bit,8,WP_Name,1,ASCII,32,WP_Latitude,0.0000001,deg,32,WP_Longitude,0.0000001,deg,0,Fields_10_thru_13_repeat_as_needed,1,,";
pgn_fields[86] = "6,8,Sequence_ID,1,bit,2,Set_Reference,1,,6,NMEA_Reserved,1,,16,Set,0.0001,rad,16,Drift,0.01,m/s,16,NMEA_Reserved,1,,";
pgn_fields[87] = "5,8,Sequence_ID,1,bit,32,Time_elapsed_(from)_or_to-go_to_mark,-0.001,s,4,Mark_Type,1,,4,NMEA_Reserved,1,,32,Mark_ID,1,bit,";
pgn_fields[88] = "10,8,Sequence_ID,1,bit,2,Bearing_Ref.,1,,2,Calculation_Type,1,,4,NMEA_Reserved,1,,16,Bearing _Origin_To_Destination,0.0001,rad,32,Distance,0.01,m,4,Origin_Mark_Type,1,,4,Destination_Mark_Type,1,,32,Origin_Mark_Id,1,bit,32,Destination_Mark_ID,1,bit,";
pgn_fields[89] = "11,16,SV_Elevation_Mask,-0.0001,rad,16,PDOP_Mask,-0.01,,16,PDOP_Switch,-0.01,,16,SNR_Mask,-0.01,dB,3,GNSS_Mode,1,,3,DGNSS_Mode,1,,2,Position_/_Velocity_Filter,1,,16,Max_Correction_Age,0.01,sec,32,Antenna_Altitude_for_2D_Mode,-0.01,m,2,Use_Antenna_Altitude_for_2D_Mode,1,,6,Reserved,1,,";
pgn_fields[90] = "7,8,Sequence_ID,1,bit,3,Set_Mode,1,,3,Op_Mode,1,,2,NMEA_Reserved,1,,16,HDOP,-0.01,,16,VDOP,-0.01,,16,TDOP,-0.01,,";
pgn_fields[91] = "18,8,Sequence_ID,1,bit,2,Mode,1,,6,NMEA_Reserved,1,,8,Number_of_SVs,1,bit,8,PRN_1,1,bit,16,Elevation_1,-0.0001,rad,16,Azimuth_1,0.0001,rad,16,SNR_1,-0.01,dB,32,Range_Residuals_1,0.00001,m,4,PRN_Status_1,1,,4,NMEA_Reserved,1,,8,PRN_n,1,bit,16,Elevation_n,-0.0001,rad,16,Azimuth_n,0.0001,rad,16,SNR_n,-0.01,dB,32,Range_Residuals_n,0.00001,m,4,PRN__Status_n,1,,4,NMEA_Reserved,1,,";
pgn_fields[92] = "14,8,PRN,1,bit,16,GPS_Week_number,1,bit,8,SV_Health_Bits,1,,16,Eccentricity,1,,8,Almanac_Reference_Time,1,,16,Inclination_Angle,1,,16,Rate_of_Right_Ascension,1,,24,Root_of_Semi-major_Axis,1,,24,Argument_of_Perigee,1,,24,Longitude_of_Ascension_Node,1,,24,Mean_Anomaly,1,,11,Clock_Parameter_1,1,,11,Clock_Parameter_2,1,,2,NMEA_Reserved,1,,";
pgn_fields[93] = "8,8,Sequence_ID,1,bit,16,RMS_of_Position_Uncertainty,0.01,m,16,STD_of_Major_axis,0.01,m,16,STD_of_Minor_axis,0.01,m,16,Orientation_of_Major_axis,0.0001,rad,16,STD_of_Lat_Error,0.01,m,16,STD_of_Lon_Error,0.01,m,16,STD_of_Alt_Error,0.01,m,";
pgn_fields[94] = "10,8,Sequence_ID,1,bit,2,Integrity_Flag,1,,6,NMEA_Reserved,1,,16,Latitude_expected_error,-0.01,m,16,Longitude_expected_error,-0.01,m,16,Altitude_expected_error,-0.01,m,8,SV_ID_of_most_likely_failed_sat,1,bit,16,Probability_of_missed_detection,-0.01,m,16,Estimate_of_pseudorange_bias,-0.01,m,16,Std_Deviation_of_bias,-0.01,m,";
pgn_fields[95] = "5,16,Radial_Position_Error_Maximum_threshold,0.01,m,8,Probability_of_False_Alarm,-1,%,8,Probability_of_Missed_Detection,-1,%,16,Pseudorange_Residual_Filtering_Time_Constant,1,second,16,NMEA_Reserved,1,,";
pgn_fields[96] = "8,8,Sequence_ID,1,bit,16,RMS_Std_Dev_of_Range_Inputs,0.01,m,16,Std_Dev_major_error_ellipse,0.01,m,16,Std_Dev_minor_error_ellipse,0.01,m,16,Orientation_of_error_ellipse,0.0001,rad,16,Std_Dev_Latitude_error,0.01,m,16,Std_Dev_Longitude_error,0.01,m,16,Std_Dev_Altitude_error,0.01,m,";
pgn_fields[97] = "11,8,Sequence_ID,1,bit,12,Reference_Station_ID,1,,4,Reference_Station_Type,1,,16,Time_of_corrections,0.1,sec,4,Station_Health,1,,4,NMEA_Reserved,1,,8,Satellite_ID,1,bit,32,PRC,-0.0001,m,16,RRC,-0.0001,m/s,16,UDRE,0.01,m,8,IOD,1,bit,";
pgn_fields[98] = "7,8,Channel,1,bit,32,Frequency,10,Hz,5,Serial_Interface_Bit_Rate,1,,3,Serial_Interface_Detection_Mode,1,,4,Differential_Source,1,,4,Differential_Operation_Mode,1,,8,NMEA_Reserved,1,,";
pgn_fields[99] = "14,8,Sequence_ID,1,bit,8,Channel,1,bit,32,Signal_Strength,-0.01,dB re";
pgn_fields[100] = "14,8,PRN,1,bit,16,NA,1,bit,2,NMEA_Reserved,1,,1,CnA,1,,5,HnA,1,,16,(epsilon)nA,1,,8,(deltaTnA)DOT,1,,16,(omega)nA,1,,24,(delta)TnA,1,,24,tnA,1,,24,(lambda)nA,1,,24,(delta)inA,1,,28,tcA,1,,12,tnA,1,,";
pgn_fields[101] = "12,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,3,NMEA_Reserved,1,,5,AIS_Spare,1,,16,Number_of_Bits_in_Binary_Data_Field,1,bit,0,Binary_Data,1,,";
pgn_fields[102] = "17,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_accuracy,1,,1,RAIM-flag,1,,6,NMEA_Reserved,1,,32,Position_time,0.0001,s,19,Communication_State,1,,5,AIS_Transceiver_Information,1,,16,Position_Date,1,day,4,NMEA_Reserved,1,,4,Type_of_Electronic_Positioning_Device,1,,10,AIS_Spare,1,,6,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[103] = "22,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,IMO,1,bit,56,Call_Sign,1,char,160,Name,1,char,8,Ship/Cargo_Type,1,,16,Ship_Length,0.1,m,16,Ship_Beam,0.1,m,16,Position_Reference_Point_from_Starboard,0.1,m,16,Position_Reference_Point_aft_of_Ship's_Bow,0.1,m,16,Estimated_Date_of_Arrival,1,day,32,Estimated_Time_of_Arrival,0.0001,s,16,Draft,0.01,m,160,Destination,1,char,2,AIS_Version,1,,4,Type_of_Electronic_Positioning_Device,1,,1,Data_Terminal_Equipment_(DTE),1,,1,AIS_Spare,1,,5,AIS_Transceiver_Information,1,,3,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[104] = "12,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,Sequence_Number,1,,32,Destination_ID,1,bit,6,NMEA_Reserved,1,,1,Retransmit_Flag,1,,1,AIS_Spare,1,,16,Number_of_Bits_in_Binary_Data_Field,1,bit,0,Binary_Data,1,,";
pgn_fields[105] = "13,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,32,Destination_ID 1,1,bit,6,NMEA_Reserved,1,,2,Sequence_Number_for_ID 1,1,,32,Destination_ID n,1,bit,6,NMEA_Reserved,1,,2,Sequence_Number_for_ID n ,1,,8,Sequence_ID,1,bit,";
pgn_fields[106] = "8,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,16,Number_of_Bits_in_Binary_Data_Field,1,bit,0,Binary_Data,1,,";
pgn_fields[107] = "18,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,RAIM-Flag,1,,6,Time_Stamp,1,,16,COG,0.0001,rad,16,SOG,0.01,m/s,19,Communication_State,1,,5,AIS_Transceiver_Information,1,,32,Altitude,-0.01,m,8,Reserved_for_Regional_Applications,1,,1,Data_Terminal_Equipment_(DTE),1,,5,AIS_Spare,1,,2,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[108] = "6,32,Rx_Frequency,10,Hz,32,Tx_Frequency,10,Hz,48,Radio_Channel,1,char,16,Tx_Power,1,W,8,Mode,1,,16,Channel_Bandwidth,1,Hz,";
pgn_fields[109] = "10,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,32,Destination_ID,1,bit,2,AIS_Spare,1,,6,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[110] = "12,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,Sequence_Number,1,,32,Destination_ID,1,bit,6,NMEA_Reserved,1,,1,Retransmit_Flag,1,,1,AIS_Spare,1,,8,Safety_Related_Text,1,ASCII,8,Sequence_ID,1,bit,";
pgn_fields[111] = "8,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,1,1,,2,AIS_Spare,1,,8,Safety_Related_Text,1,ASCII,8,Sequence_ID,1,bit,";
pgn_fields[112] = "22,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,32,Destination_ID_1,1,bit,2,NMEA_Reserved,1,,6,Message_ID_1.1,1,,16,Slot_Offset_1.1,1,bit,2,AIS_Spare,1,,6,Message_ID_1.2,1,,16,Slot_Offset_1.2,1,bit,6,NMEA_Reserved,1,,2,AIS_Spare,1,,32,Destination_ID_2,1,bit,2,NMEA_Reserved,1,,6,Message_ID_2.1,1,,16,Slot_Offset_2.1,1,bit,2,AIS_Spare,1,,6,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[113] = "15,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,32,Destination_ID_A,1,bit,16,Offset_A,1,bit,16,Increment_A,1,bit,32,Destination_ID_B,1,bit,16,Offset_B,1,bit,16,Increment_B,1,bit,4,AIS_Spare,1,,4,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[114] = "25,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_Station_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,16,Offset_Number_1,1,bit,8,Number_of_Slots_1,1,bit,8,Time_Out_1,1,bit,16,Increment_1,1,bit,16,Offset_Number_2,1,bit,8,Number_of_Slots_2,1,bit,8,Time_Out_2,1,bit,16,Increment_2,1,bit,16,Offset_Number_3,1,bit,8,Number_of_Slots_3,1,bit,8,Time_Out_3,1,bit,16,Increment_3,1,bit,16,Offset_Number_4,1,bit,8,Number_of_Slots_4,1,bit,8,Time_Out_4,1,bit,16,Increment_4,1,bit,6,AIS_Spare,1,,2,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[115] = "27,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Station_ID,1,bit,1,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,2,AIS_Spare,1,,16,Channel_A,1,bit,16,Channel_B,1,bit,3,Source_Identifier,1,,1,Power,1,,4,Tx/Rx_Mode,1,,32,North_East_Longitude_Corner_1,0.0000001,deg,32,North_East_Latitude_Corner_1,0.0000001,deg,32,South_West_Longitude_Corner_2,0.0000001,deg,32,South_West_Latitude_Corner_2,0.0000001,deg,1,NMEA_Reserved,1,,1,Addressed_or_Broadcast_Message_Indicator,1,,1,Channel_A_Bandwidth,1,,1,Channel_B_Bandwidth,1,,1,NMEA_Reserved,1,,3,Transitional_Zone_Size,1,,23,AIS_Spare,1,,1,NMEA_Reserved,1,,2,In-Use_Flag,1,,6,NMEA_Reserved,1,,32,Time_of_in-use_Flag_Change,0.0001,s,8,Sequence_ID,1,bit,";
pgn_fields[116] = "22,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,2,AIS_Spare,1,,4,Tx/Rx_Mode,1,,2,NMEA_Reserved,1,,32,North_East_Longitude_Corner_1,0.0000001,deg,32,North_East_Latitude_Corner_1,0.0000001,deg,32,South_West_Longitude_Corner_2,0.0000001,deg,32,South_West_Latitude_Corner_2,0.0000001,deg,4,Station_Type,1,,4,NMEA_Reserved,1,,8,Ship_and_Cargo_Filter,1,,22,AIS_Spare,1,,2,NMEA_Reserved,1,,4,Reporting_Interval,1,,4,Quiet_Time,1,,6,AIS_Spare,1,,2,NMEA_Reserved,1,,5,AIS_Transceiver_Information,1,,3,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[117] = "24,8,DSC_Format_Symbol,1,bit,8,DSC_Category_Symbol,1,bit,40,DSC_Message_Address,1,char,8,Nature_Of_Distress_or_1st_Telecommand,1,bit,8,Subsequent_Communication_Mode_or_2nd_Telecommand,1,bit,48,Proposed_Rx_Frequency_/_Channel,1,char,48,Proposed_Tx_Frequency_/_Channel,1,char,8,Telephone_Number,1,ASCII,32,Latitude_of_Vessel_Reported,0.0000001,deg,32,Longitude_of_Vessel_Reported,0.0000001,deg,32,Time_of_Position,0.0001,s,40,MMSI_Of_Ship_In_Distress,1,char,8,DSC_EOS_Symbol,1,bit,2,Expansion_Enabled,1,,6,NMEA_Reserved,1,,48,Calling_Rx_Frequency/Channel,1,char,48,Calling_Tx_Frequency/Channel,1,char,32,Time_of_Receipt/Transmission,0.0001,s,16,Date_of_Receipt/Transmission,1,day,16,DSC_Equipment_Assigned_Message_ID,1,bit,8,DSC_Expansion_Field_Symbol,1,bit,8,DSC_Expansion_Field_Data,1,ASCII,8,Variable_Number_Of_Fields _Field_21_Repeated _Expansion_Field_Type,1,bit,8,Variable_Number_Of_Fields _Field_22_Repeated _Expansion_Field_Data,1,ASCII,";
pgn_fields[118] = "7,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,160,Name,1,char,5,AIS_Transceiver_Information,1,,3,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[119] = "16,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,8,Type_of_Ship_and_Cargo,1,,56,Vendor_ID,1,char,56,Call_Sign,1,char,16,Ship_Length,0.1,m,16,Ship_Beam,0.1,m,16,Reference_Point_Position_from_Starboard,0.1,m,16,Reference_Point_Position_Aft_of_Bow,0.1,m,32,Mother_Ship_MMSI,1,bit,2,NMEA_Reserved,1,,6,AIS_Spare,1,,5,AIS_Transceiver_Information,1,,3,NMEA_Reserved,1,,8,Sequence_ID,1,bit,";
pgn_fields[120] = "11,8,Sequence_ID,1,bit,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,Destination_Indicator,1,,1,Binary_data_flag,1,,2,AIS_Spare,1,,4,NMEA_Reserved,1,,32,Destination_ID,1,bit,8,Number_of_bits_in_Binary_Data_Field,1,bit,0,Binary_Data,1,,";
pgn_fields[121] = "23,8,Sequence_ID,1,bit,6,Message_ID,1,,2,Repeat_Indicator,1,,32,Source_ID,1,bit,1,Destination_Indicator,1,,1,Binary_data_flag,1,,6,NMEA_Reserved,1,,32,Destination_ID,1,bit,2,AIS_Spare,1,,1,Communication_state_selector_flag,1,,19,Communication_state,1,,4,AIS_Spare,1,,6,NMEA_Reserved,1,,8,Number_of_Bits_in_Binary_Data_Field_1st_slot,1,bit,8,Number_of_Bits_in_Binary_Data_Field_2nd_slot,1,bit,8,Number_of_Bits_in_Binary_Data_Field_3rd_slot,1,bit,8,Number_of_Bits_in_Binary_Data_Field_4th_slot,1,bit,8,Number_of_Bits_in_Binary_Data_Field_5th_slot,1,bit,0,Binary_Data__1st_slot,1,,0,Binary_Data__2nd_slot,1,,0,Binary_Data__3rd_slot,1,,0,Binary_Data__4th_slot,1,,0,Binary_Data__5th_slot,1,,";
pgn_fields[122] = "13,8,Sequence_ID,1,bit,6,Message_ID,1,,2,Repeat_Indicator,1,,32,User_ID,1,bit,32,Longitude,0.0000001,deg,32,Latitude,0.0000001,deg,1,Position_Accuracy,1,,1,Raim_Flag,1,,4,Navigation_Status,1,,1,Position_Latency,1,,1,AIS_Spare,1,,16,Speed_Over_Ground,0.01,m/s,16,Course_Over_Ground,0.0001,rad,";
pgn_fields[123] = "15,32,Group_Repetition_Interval_(GRI),0.000000001,s,32,Master_Range,0.000000001,s,32,V_Secondary_TD,0.000000001,s,32,W_Secondary_TD,0.000000001,s,32,X_Secondary_TD,0.000000001,s,32,Y_Secondary_TD,0.000000001,s,32,Z_Secondary_TD,0.000000001,s,4,Station_status";
pgn_fields[124] = "15,32,Group_Repetition_Interval_(GRI),0.000000001,s,32,Master_Range,0.000000001,s,32,V_Secondary_Range,0.000000001,s,32,W_Secondary_Range,0.000000001,s,32,X_Secondary_Range,0.000000001,s,32,Y_Secondary_Range,0.000000001,s,32,Z_Secondary_Range,0.000000001,s,4,Station_status";
pgn_fields[125] = "5,32,Group_Repetition_Interval_(GRI),0.000000001,s,8,Station_identifier,1,char,16,Station_SNR,-0.01,dB,32,Station_ECD,0.000000001,s,32,Station_ASF,0.000000001,s,";
pgn_fields[126] = "8,8,Hardware_Channel_ID,1,bit,24,PGN,1,,8,Data_Source_Instance_Field_Number,1,bit,8,Data_Source_Instance_Value,1,,8,Secondary_Enumeration_Field_Number,1,bit,8,Secondary_Enumeration_Field_Value,1,bit,8,Parameter_Field_Number,1,bit,8,Label,1,ASCII,";
pgn_fields[127] = "11,8,Data_Source_Channel_ID,1,bit,2,Source_Selection_Status,1,,2,NMEA_Reserved,1,,12,NAME_Selection_Criteria_Mask,1,,64,Source_NAME,1,bit,24,PGN,1,,8,Data_Source_Instance_Field_Number,1,bit,8,Data_Source_Instance_Value,1,,8,Secondary_Enumeration_Field_Number,1,bit,8,Secondary_Enumeration_Field_Value,1,bit,8,Parameter_Field_Number,1,bit,";
pgn_fields[128] = "13,16,Start_Database_ID,1,bit,16,nItems,1,bit,16,Number_of_Databases_available,1,bit,16,Database_ID,1,bit,8,Database_Name,1,ASCII,32,Database_Timestamp,0.0001,s,16,Database_Datestamp,1,day,4,WP_Position_Resolution,1,,4,NMEA_Reserved,1,,16,Number_of_Routes_in_Database,1,bit,32,Number_of_WPs_in_Database,1,bit,32,Number_of_Bytes_in_Database,1,bit,0,Fields_4_thru_12_repeat_as_needed,1,,";
pgn_fields[129] = "10,16,Start_Route_ID,1,bit,16,nItems,1,bit,16,Number_of_Routes_available_in_Database,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,8,Route_Name,1,ASCII,2,NMEA_Reserved,1,,2,WP_Identification_Method,1,,4,Route_Status,1,,0,Fields_5_thru_9_repeat_as_needed,1,,";
pgn_fields[130] = "13,16,Database_ID,1,bit,16,Route_ID,1,bit,8,Route/WP-List_Name,1,ASCII,32,Route/WP-List_Timestamp,0.0001,s,16,Route/WP-List_Datestamp,1,day,8,Change_at_Last_Timestamp,1,,16,Number_of_WPs_in_the_Route/WP-List,1,bit,8,Critical_supplementary_parameters,1,,2,Navigation_Method,1,,2,WP_Identification_Method,1,,4,Route_Status,1,,16,XTE_Limit_for_the_Route,-1,m,0,NMEA_Reserved,1,,";
pgn_fields[131] = "10,16,Start_RPS#,1,bit,16,nItems,1,bit,16,Number_of_WPs_in_the_Route,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,16,WPID,1,bit,8,WP_Name,1,ASCII,32,WP_Latitude,0.0000001,deg,32,WP_Longitude,0.0000001,deg,0,Fields_6_thru_9_repeat_as_needed,1,,";
pgn_fields[132] = "8,16,Start_RPS#,1,bit,16,nItems,1,bit,16,Number_of_WPs_in_the_Route,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,16,WPID,1,bit,8,WP_Name,1,ASCII,0,field_6_thru_7_repeat_as__needed,1,,";
pgn_fields[133] = "10,16,Start_RPS#,1,bit,16,nItems,1,bit,16,Number_of_Waypoints_with_a_specific_XTE_Limit_or_Nav._Method,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,16,RPS#,1,bit,16,XTE_limit_in_the_leg_after_WP,-1,m,2,Nav.__Method_in_the_leg_after_WP,1,,6,NMEA_Reserved,1,,0,Fields_6_thru_9_repeat_as_needed,1,,";
pgn_fields[134] = "8,16,Start_ID,1,bit,16,nItems,1,bit,16,Number_of_WPs_with_Comments,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,16,WPID_/_RPS#,1,bit,8,Comment,1,ASCII,0,Fields_6_thru_7_repeat_as_needed,1,,";
pgn_fields[135] = "7,16,Start_Route_ID,1,bit,16,nItems,1,bit,16,Number_of_Routes_with_Comments,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,8,Comment,1,ASCII,0,Fields_5_thru_6_repeat_as_needed,1,,";
pgn_fields[136] = "6,16,Start_Database_ID,1,bit,16,nItems,1,bit,16,Number_of_Databases_with_comments,1,bit,16,Database_ID,1,bit,8,Comment_text,1,ASCII,0,Fields_4_thru_5_repeat_as_needed,1,,";
pgn_fields[137] = "8,16,Start_RPS#,1,bit,16,nItems,1,bit,16,Number_of_Waypoints_with_a_specific_Radius_of_Turn,1,bit,16,Database_ID,1,bit,16,Route_ID,1,bit,16,RPS#,1,bit,16,Radius_of_Turn,-1,m,0,Fields_6_and_7_repeated_as_needed,1,,";
pgn_fields[138] = "10,16,Start_WPID,1,bit,16,nItems,1,bit,16,Number_of_valid_WPs_in_the_WP-List,1,bit,16,Database_ID,1,bit,16,NMEA_Reserved,1,,16,WPID,1,bit,8,WP_Name,1,ASCII,32,WP_Latitude,0.0000001,deg,32,WP_Longitude,0.0000001,deg,0,Fields_6_thru_9_repeat_as_needed,1,,";
pgn_fields[139] = "5,8,Sequence_ID,1,bit,16,Wind_Speed,0.01,m/s,16,Wind_Direction,0.0001,rad,3,Wind_Reference,1,,21,NMEA_Reserved,1,,";
pgn_fields[140] = "5,8,Sequence_ID,1,bit,16,Water_Temp,0.01,deg K,16,Outside_Ambient_Air_Temp.,0.01,deg K,16,Atmospheric_Pressure,100,Pa,8,NMEA_Reserved,1,,";
pgn_fields[141] = "6,8,Sequence_ID,1,bit,6,Temperature_Instance,1,,2,Humidity_Instance,1,,16,Temperature,0.01,deg K,16,Humidity,-0.004,%,16,Atmospheric_Pressure,100,Pa,";
pgn_fields[142] = "6,8,Sequence_ID,1,bit,8,Temperature_Instance,1,,8,Temperature_Source,1,,16,Actual_Temp,0.01,deg K,16,Set_Temp,0.01,deg K,8,NMEA_Reserved,1,,";
pgn_fields[143] = "6,8,Sequence_ID,1,bit,8,Humidity_Instance,1,,8,Humidity_Source,1,,16,Actual_Humidity,-0.004,%,16,Set_Humidity,-0.004,%,8,NMEA_Reserved,1,,";
pgn_fields[144] = "5,8,Sequence_ID,1,bit,8,Pressure_Instance,1,,8,Pressure_Source,1,,32,Pressure,-0.1,Pa,8,NMEA_Reserved,1,,";
pgn_fields[145] = "5,8,Sequence_ID,1,bit,8,Pressue_Instance,1,,8,Pressure_Source,1,,32,Pressure,-0.1,Pa,8,NMEA_Reserved,1,,";
pgn_fields[146] = "5,8,Sequence_ID,1,bit,8,Temperature_Instance,1,,8,Temperature_Source,1,,24,Actual_Temp,0.001,deg K,16,Set_Temp,0.1,deg K,";
pgn_fields[147] = "11,4,Mode,1,,2,Tide_Tendency,1,,2,NMEA_Reserved,1,,16,Measurement_date,1,day,32,Measurement_time,0.0001,s,32,Station_location _latitude,0.0000001,deg,32,Station_location _longitude,0.0000001,deg,16,Tide_level,-0.001,m,16,Tide_level_standard_deviation,0.01,m,8,Station_ID_String,1,ASCII,8,Station_Name_String,1,ASCII,";
pgn_fields[148] = "10,4,Mode,1,,4,NMEA_Reserved,1,,16,Measurement_Date,1,day,32,Measurement_time,0.0001,s,32,Station_location _latitude,0.0000001,deg,32,Station_location _longitude,0.0000001,deg,32,Salinity,1,,16,Water_Temperature,0.01,deg K,8,Station_ID_String,1,ASCII,8,Station_Name_String,1,ASCII,";
pgn_fields[149] = "13,4,Mode,1,,3,State,1,,1,NMEA_Reserved,1,,16,Measurement_date,1,day,32,Measurement_time,0.0001,s,32,Station_location _latitude,0.0000001,deg,32,Station_location _longitude,0.0000001,deg,32,Measurement_depth,0.01,m,16,Current_speed,0.01,m/s,16,Current_flow_direction,0.0001,rad,16,Water_Temperature,0.01,deg K,8,Station_ID_String,1,ASCII,8,Station_Name_String,1,ASCII,";
pgn_fields[150] = "15,4,Mode,1,,4,NMEA_Reserved,1,,16,Measurement_date,1,day,32,Measurement_time,0.0001,s,32,Station_location _latitude,0.0000001,deg,32,Station_location _longitude,0.0000001,deg,16,Wind_Speed,0.01,m/s,16,Wind_Direction,0.0001,rad,3,Wind_Reference,1,,5,NMEA_Reserved,1,,16,Wind_Gusts,0.01,m/s,16,Atmospheric_Pressure,100,Pa,16,Air_Temperature,0.01,deg K,8,Station_ID_String,1,ASCII,8,Station_Name_String,1,ASCII,";
pgn_fields[151] = "18,4,Mode,1,,4,NMEA_Reserved,1,,16,Measurement_date,1,day,32,Measurement_time,0.0001,s,32,Station_location _latitude,0.0000001,deg,32,Station_location _longitude,0.0000001,deg,16,Wind_Speed,0.01,m/s,16,Wind_Direction,0.0001,rad,3,Wind_Reference,1,,5,_NMEA_Reserved,1,,16,Wind_Gusts,0.01,m/s,16,Wave_Height,0.01,m,16,Dominate_Wave_Period,0.01,sec,16,Atmospheric_Pressure,100,Pa,16,Pressure_Tendency_Rate,-10,Pa/hr,16,Air_temperature,0.01,deg K,16,Water_temperature,0.01,deg K,8,Station_ID_String,1,ASCII,";
pgn_fields[152] = "6,8,Sequence_ID,1,bit,3,Measurement_Status,1,,5,NMEA_Reserved,1,,8,Measurement_ID,1,bit,32,Payload_Mass,0.0001,kg,8,NMEA_Reserved,1,,";
pgn_fields[153] = "23,6,Watermaker_Operating_State,1,,2,Production_Start/Stop,1,,2,Rinse_Start/Stop,1,,2,Low_Pressure_Pump_Status,1,,2,High_Pressure_Pump_Status,1,,2,Emergency_Stop,1,,2,Product_Solenoid_Valve_Status,1,,2,Flush_Mode_Status,1,,2,Salinity_Status,1,,2,Feed_Pressure_Status,1,,2,Oil_Change_Indicator_Status,1,,2,Filter_Status,1,,2,System_Status,1,,2,NMEA_Reserved,1,,16,Salinity,1,ppm,16,Product_Water_Temperature,0.01,deg K,16,Pre-filter_Pressure,100,Pa,16,Post-filter_Pressure,100,Pa,16,Feed_Pressure,-1,Kpa,16,System_High_Pressure,1000,Pa,16,Product_Water_Flow,-0.0001,cu-m/hr,16,Brine_Water_Flow,-0.0001,cu-m/hr,32,Run_Time,1,sec,";
pgn_fields[154] = "15,8,Zone_Number,1,,8,Audio/Video_Source_Type,1,,8,Audio/Video_Source_Number,1,bit,32,File_ID,1,bit,8,Play_Status,1,,16,Elapsed_Track/Chapter_Time,1,second,16,Track/Chapter_Time,1,second,4,Repeat_Status,1,,4,Shuffle_Status,1,,8,Save_Favorite_Number_(write_only),1,bit,8,Play_Favorite_Number,1,bit,8,Thumbs_Up/Thumbs_Down,1,,8,Signal_Strength,1,%,32,Radio_Frequency,10,Hz,8,HD_Frequency_Multicast,1,bit,";
pgn_fields[155] = "12,8,Audio/Video_Source_Type,1,,8,Audio/Video_Source_Number,1,bit,32,File_ID,1,bit,8,Library_Data_Type,1,,8,Library_Data_Name,1,ASCII,16,Track/Chapter_Number,1,bit,16,Station_Number,1,bit,8,Favorite_Number,1,bit,32,Radio_Frequency,10,Hz,8,HD_Frequency_Multi-Cast,1,bit,8,Play_Queue_Zone_Number,1,,2,In_Play_Queue,1,,";
pgn_fields[156] = "12,8,Audio/Video_Source_Type,1,,8,Audio/Video_Source_Number,1,bit,8,Group_Type,1,,8,Play_Queue_Zone_Number,1,,32,Group_ID,1,bit,16,Index_of_first_ID_in_PGN,1,bit,16,Number_of_IDs_in_this_PGN,1,bit,16,Total_number_of_IDs_available,1,bit,8,ID_Type,1,,32,ID,1,bit,8,ID_Name,1,ASCII,0,Fields_9_11_repeat_as_needed,1,,";
pgn_fields[157] = "9,8,Audio/Video_Source_Type,1,,8,Audio/Video_Source_Number,1,bit,32,Group_ID,1,bit,8,Library_Group_Type_1,1,,8,Library_Data_Name_1,1,ASCII,8,Library_Group_Type_2,1,,8,Library_Data_Name_2,1,ASCII,8,Library_Group_Type_3,1,,8,Library_Data_Name_3,1,ASCII,";
pgn_fields[158] = "15,8,Index_of_first_Source_ID_in_this_PGN,1,bit,8,Number_of_Source_IDs_in_this_PGN,1,bit,8,Total_number_of_Source_IDs_available,1,bit,8,Source_ID,1,bit,8,Audio/Video_Source_Type,1,,8,Audio/Video_Source_Number,1,bit,8,Audio/Video_Source_Name,1,ASCII,32,Supported_Play_Status,1,,16,Supported_Browsing_Methods,1,,2,Thumbs_Supported,1,,2,Source_Connected,1,,4,NMEA_Reserved,1,,4,Repeat_Supported,1,,4,Shuffle_Supported,1,,0,Fields_4_12_repeat_as_needed,1,,";
pgn_fields[159] = "6,8,Index_of_first_Zone_Number_in_this_PGN,1,bit,8,Number_of_Zone_Numbers_in_this_PGN,1,bit,8,Total_number_of_Zone_Numbers_available,1,bit,8,Zone_Number,1,,8,Zone_Name,1,ASCII,0,Fields_4_5_repeat_as_needed,1,,";
pgn_fields[160] = "3,8,Port_trim_tab,-1,%,8,Starboard_trim_tab,-1,%,48,NMEA_Reserved,1,,";
pgn_fields[161] = "10,4,Data_Mode,1,,2,Set/COG/Heading_Ref.,1,,2,NMEA_Reserved,1,,8,Sequence_ID,1,bit,16,Course_Over_Ground,0.0001,rad,16,Speed_Over_Ground,0.01,m/s,16,Heading,0.0001,rad,16,Speed_through_Water,0.01,m/s,16,Set,0.0001,rad,16,Drift,0.01,m/s,";
pgn_fields[162] = "6,16,Longitudinal_Speed _Water-referenced,-0.001,m/s,16,Transverse_Speed _Water-referenced,-0.001,m/s,16,Longitudinal_Speed _Ground-referenced,-0.001,m/s,16,Transverse_Speed _Ground-referenced,-0.001,m/s,16,Stern_Speed _Water-referenced,-0.001,m/s,16,Stern_Speed _Ground-referenced,-0.001,m/s,";
pgn_fields[163] = "4,2,Power,1,,2,Default_Settings,1,,4,Tuner_Regions,1,,8,Supported_Number_of_Favorites_(read_only),1,bit,";
pgn_fields[164] = "12,8,Zone_Number,1,,8,Volume_Limit,1,%,8,Fade,-1,%,8,Balance,-1,%,8,Non-Fader _Sub_Volume,1,%,8,Equalizer_Treble,-1,%,8,Equalizer_Mid_Range,-1,%,8,Equalizer_Bass,-1,%,8,EQ_Preset_Type,1,,8,Audio_Filter_Setting,1,,32,High-Pass_Filter_Frequency_(read_only),10,Hz,32,Low-Pass_Filter_Frequency_(read_only),10,Hz,";
pgn_fields[165] = "5,8,Zone_Number,1,,8,Zone_Volume_Absolute,1,%,2,Zone_Volume_Relative_(Write_Only),1,,2,Mute,1,,4,NMEA_Reserved,1,,";
pgn_fields[166] = "6,8,Index_of_first_EQ_Preset_Type_in_this_PGN,1,bit,8,Number_of_EQ_Preset_Types_in_this_PGN,1,bit,8,Total_number_of_EQ_Preset_Types_available,1,bit,8,EQ_Preset_Type,1,,8,EQ_Preset_Name,1,ASCII,0,Fields_4_5_repeat_as_needed,1,,";
pgn_fields[167] = "8,8,Index_of_first_Bluetooth_Address_in_this_PGN,1,bit,8,Number_of_Bluetooth_Addresses_in_this_PGN,1,bit,8,Number_of_Bluetooth_Addresses_available,1,bit,48,Bluetooth_Device_Address,1,,8,Bluetooth_Device_Status,1,,8,Bluetooth_Device_Name,1,ASCII,8,Bluetooth_Signal_Strength,1,%,0,Fields_4_7_repeat_as_needed,1,,";
pgn_fields[168] = "5,8,Bluetooth_Source_Number,1,bit,4,Bluetooth_Pairing_Status,1,,2,Forget_Bluetooth_Device,1,,2,NMEA_Reserved,1,,48,Bluetooth_Device_Address,1,,";
pgn_fields[169] = "4,11,Manufacturer Code,1,,2,NMEA Reserved,1,,3,Industry Group,1,,16,Manufacturer Defined,1,,";
pgn_fields[170] = "3,8,Sequence_ID,1,bit,16,Nautical Leeway Angle,-0.0001,rad,40,NMEA Reserved,1,,";
pgn_fields[171] = "9,8,Sequence_ID,1,bit,8,Thruster Identifier,1,,4,Thruster Direction Control,1,,2,Power Enable,1,,2,Thruster Retract Control,1,,8,Speed Control,0.00005,,8,Thruster Control Events,1,,8,Command Timeout,0.005,s,16,Azimuth Control,-0.0001,rad,";
pgn_fields[172] = "6,8,Thruster Identifier,1,,4,Thruster Motor Type,1,,4,NMEA Reserved,1,,16,Motor Power Rating,1,W,16,Maximum Motor Temperature Rating,0.01,K,16,Maximum Rotational Speed,0.25,RPM,";
pgn_fields[173] = "6,8,Sequence_ID,1,bit,8,Thruster Identifier,1,,8,Thruster Motor Events,1,,8,Motor Current,1,A,16,Motor Temperature,0.01,K,16,Total Motor Operating Time,1,minute,";
pgn_fields[174] = "31,8,Sequence_ID,1,bit,8,Elevator Car ID,1,,4,Elevator Car Usage,1,,2,Smoke Sensor Status,1,,2,Limit Switch Sensor Status,1,,2,Proximity Switch Sensor Status,1,,2,Inertial Measurement Unit (IMU) Sensor Status,1,,2,Elevator Load Limit Status,1,,2,Elevator Load Balance Status,1,,2,Elevator Load Sensor 1 Status,1,,2,Elevator Load Sensor 2 Status,1,,2,Elevator Load Sensor 3 Status,1,,2,Elevator Load Sensor 4 Status,1,,2,NMEA_Reserved,1,,2,Elevator Car Motion Status,1,,2,Elevator Car Door Status,1,,2,Elevator Car Emergency Button Status,1,,2,Elevator Car Buzzer Status,1,,2,Open Door Button Status,1,,2,Close Door Button Status,1,,2,NMEA_Reserved,1,,8,Current Deck Position,-1,,8,Destination Deck,-1,,8,Total Number of Decks,1,,16,Weight of Elevator Car load cell No. 1,1,kg,16,Weight of Elevator Car load cell No. 2,1,kg,16,Weight of Elevator Car load cell No. 3,1,kg,16,Weight of Elevator Car load cell No. 4,1,kg,8,Speed of Elevator Car,0.1,m/s,2,Elevator Brake Status,1,,4,Elevator Motor rotation control status,1,,";
pgn_fields[175] = "6,8,Sequence_ID,1,bit,8,Elevator car ID,1,,4,Elevator car usage,1,,4,Motor Acceleration/Deceleration profile selection,1,,2,Motor rotation control status,1,,38,NMEA_Reserved,1,,";
pgn_fields[176] = "6,8,Sequence_ID,1,bit,8,Elevator call button ID,1,,8,Deck button ID,-1,,4,Elevator car usage,1,,2,Elevator call button selection,1,,34,NMEA_Reserved,1,,";
pgn_fields[177] = "14,8,Sequence_ID,1,bit,8,Windlass Identifier,1,,2,Windlass Direction Control,1,,2,Anchor Docking Control,1,,2,Speed Control Type,1,,2,NMEA_Reserved,1,,8,Speed Control,1,,2,Power Enable,1,,2,Mechanical Lock,1,,2,Deck and Anchor wash,1,,2,Anchor Light,1,,8,Command Timeout,0.005,s,4,Windlass Control Events,1,,4,NMEA_Reserved,1,,";
pgn_fields[178] = "9,8,Sequence_ID,1,bit,8,Windlass Identifier,1,,2,Windlass Motion Status,1,,2,Rode Type Status,1,,4,NMEA_Reserved,1,,16,Rode Counter Value,0.01,,16,Windlass Line Speed,0.01,knots,2,Anchor Docking Status,1,,6,Windlass Operating Events,1,,";
pgn_fields[179] = "7,8,Sequence_ID,1,bit,8,Windlass Identifier,1,,8,Windlass Monitoring Events,1,,8,Controller Voltage,0.2,V,8,Motor Current,1,A,16,Total Motor Time,1,min,8,NMEA_Reserved,1,,";
pgn_fields[180] = "6,8,Actuator_Identifier,1,bit,8,Commanded_Device_Position,1,%,8,Device Position,1,%,16,Maximum Device Travel,0.0001,m,2,Direction of Travel,1,bit,22,NMEA_Reserved,1,,";
pgn_fields[181] = "16,11,Manufacturer Code,1,,2,NMEA_Reserved,1,,3,Industry Group,1,,8,DC Instance,1,,8,Operating Status,1,,16,Output Voltage,0.01,V,16,Output Current,0.1,A,16,Panel Voltage,0.01,V,16,Panel Power,1,W,16,Max Power Today,1,W,16,Max Power Yesterday,1,W,16,Solar Yield Today,1,kWh,16,Solar Yield Yesterday,1,kWh,16,Load Current,0.1,A,2,Load Status,1,,14,NMEA_Reserved,1,,";

const pgnTitles = [
    "59392-ISO Acknowledgment",
    "59904-ISO Request",
    "60160-ISO Transport Protocol Data Transfer",
    "60416-ISO Transport Protocol Connection Management",
    "60928-ISO Address Claim",
    "65240-ISO Commanded Address",
    "126208-NMEA Request group function",
    "126464-PGN List Received PGNs group function",
    "126983-Alert",
    "126984-Alert Response",
    "126985-Alert Text",
    "126986-Alert Configuration",
    "126987-Alert Threshold",
    "126988-Alert Value",
    "126992-System Time",
    "126993-Heartbeat",
    "126996-Product Information",
    "126998-Configuration Information",
    "127233-Man Overboard Notification(MOB)",
    "127237-Heading/Track Control",
    "127245-Rudder",
    "127250-Vessel Heading",
    "127251-Rate of Turn",
    "127252-Heave",
    "127257-Attitude",
    "127258-Magnetic Variation",
    "127488-Engine Parameters Rapid Update",
    "127489-Engine Parameters Dynamic",
    "127493-Transmission Parameters Dynamic",
    "127496-Trip Fuel Consumption Vessel",
    "127497-Trip Fuel Consumption Engine",
    "127498-Engine Parameters Static",
    "127500-Load Controller Connection State/Control",
    "127501-Binary Status Report",
    "127502-Switch Bank Control",
    "127503-AC Input Status",
    "127504-AC Output Status",
    "127505-Fluid Level",
    "127506-DC Detailed Status",
    "127507-Charger Status",
    "127508-Battery Status",
    "127509-Inverter Status",
    "127510-Charger Configuration Status",
    "127511-Inverter Configuration Status",
    "127512-AGS Configuration Status",
    "127513-Battery Configuration Status",
    "127514-AGS Status",
    "127744-AC Power/Current Phase A",
    "127745-AC Power/Current Phase B",
    "127746-AC Power/Current Phase C",
    "127747-AC Voltage/Frequency Phase A",
    "127748-AC Voltage/Frequency Phase B",
    "127749-AC Voltage/Frequency Phase C",
    "127750-Converter(Inverter/Charger) Status",
    "127751-DC Voltage/Current",
    "128000-Nautical Leeway Angle",
    "128006-Thruster Control Status",
    "128007-Thruster Information",
    "128008-Thruster Motor Status",
    "128259-Speed Water Referenced",
    "128267-Water Depth",
    "128275-Distance Log",
    "128520-Tracked Target Data",
    "128538-Elevator Car Status",
    "128768-Elevator Motor Control",
    "128769-Elevator Deck Push Button",
    "128776-Windlass Control Status",
    "128777-Anchor Windlass Operating",
    "128778-Anchor Windlass Monitoring ",
    "128780-Linear Actuator",
    "129025-Position Rapid Update",
    "129026-COG & SOG Rapid Update",
    "129027-Position Delta High Precision Rapid Update",
    "129028-Altitude Delta High Precision Rapid Update",
    "129029-GNSS Position Data",
    "129033-Local Time Offset",
    "129038-AIS Class A Position Report",
    "129039-AIS Class B Position Report",
    "129040-AIS Class B Extended Position Report",
    "129041-AIS Aids to Navigation (AtoN) Report",
    "129044-Datum",
    "129045-User Datum Settings",
    "129283-Cross Track Error",
    "129284-Navigation Data",
    "129285-Navigation Route/WP information",
    "129291-Set & Drift Rapid Update",
    "129301-Time to/from Mark",
    "129302-Bearing and Distance between two Marks",
    "129538-GNSS Control Status",
    "129539-GNSS DOPs",
    "129540-GNSS Sats in View",
    "129541-GPS Almanac Data",
    "129542-GNSS Pseudorange Noise Statistics",
    "129545-GNSS RAIM Output",
    "129546-GNSS RAIM Settings",
    "129547-GNSS Pseudorange Error Statistics",
    "129549-DGNSS Corrections",
    "129550-GNSS Differential Correction Receiver Interface",
    "129551-GNSS Differential Correction Receiver Signal",
    "129556-GLONASS Almanac Data",
    "129792-AIS DGNSS Broadcast Binary Message",
    "129793-AIS UTC and Date Report",
    "129794-AIS Class A Static and Voyage Related Data",
    "129795-AIS Addressed Binary Message",
    "129796-AIS Acknowledge",
    "129797-AIS Binary Broadcast Message",
    "129798-AIS SAR Aircraft Position Report",
    "129799-Radio Frequency/Mode/Power",
    "129800-AIS UTC/Date Inquiry",
    "129801-AIS Addressed Safety Related Message",
    "129802-AIS Safety Related Broadcast Message",
    "129803-AIS Interrogation",
    "129804-AIS Assignment Mode Command",
    "129805-AIS Data Link Management Message",
    "129806-AIS Channel Management",
    "129807-AIS Group Assignment",
    "129808-DSC Call Information",
    "129809-AIS Class B CS Static Data Report Part A",
    "129810-AIS Class B CS Static Data Report Part B",
    "129811-AIS Single Slot Binary Message",
    "129812-AIS Multi Slot Binary Message",
    "129813-AIS Long-Range Broadcast Message",
    "130052-LoranC TD Data",
    "130053-LoranC Range Data",
    "130054-LoranC Signal Data",
    "130060-Label",
    "130061-Channel Source Configuration",
    "130064-Route and WP Service Database List",
    "130065-Route and WP Service Route List",
    "130066-Route and WP Service Route/WP-List Attributes",
    "130067-Route and WP Service Route WP Name & Position",
    "130068-Route and WP Service Route WP Name",
    "130069-Route and WP Service XTE Limit & Navigation Method",
    "130070-Route and WP Service WP Comment",
    "130071-Route and WP Service Route Comment",
    "130072-Route and WP Service Database Comment",
    "130073-Route and WP Service Radius of Turn",
    "130074-Route and WP Service WP List WP Name & Position",
    "130306-Wind Data",
    "130310-Environmental Parameters",
    "130311-Environmental Parameters",
    "130312-Temperature",
    "130313-Humidity",
    "130314-Actual Pressure",
    "130315-Set Pressure",
    "130316-Temperature Extended",
    "130320-Tide Station Data",
    "130321-Salinity Station  Data",
    "130322-Current Station Data",
    "130323-Meteorological Station Data",
    "130324-Moored Buoy Station Data",
    "130560-Payload Mass",
    "130567-Watermaker Input Setting and Status",
    "130569-Entertainment Current File and Status",
    "130570-Entertainment Library Data File",
    "130571-Entertainment Library Data Group",
    "130572-Entertainment Library Data Search",
    "130573-Entertainment Supported Source Data",
    "130574-Entertainment Supported Zone Data",
    "130576-Trim Tab Status",
    "130577-Direction Data",
    "130578-Vessel Speed Components",
    "130580-Entertainment System Configuration Status",
    "130581-Entertainment Zone Configuration Status",
    "130582-Entertainment Zone Volume Status",
    "130583-Entertainment Available Audio EQ Presets",
    "130584-Entertainment Bluetooth Devices",
    "130585-Entertainment Bluetooth Source Status",
    "130900-Proprietary PGN for Solar Panel Controller",
    "000001-Unknown PGN",
    "000000-empty"
];

const KFData = [
    '10120-System Tools-NMEA 2000 Certification Tool',
    '10121-System Tools-NMEA OneNet Certification Tool',
    '10122-System Tools-OneNet Gateway Certification Tool NMEA 2000 Side',
    '10123-System Tools-OneNet Gateway Certification Tool OneNet Side',
    '10130-System Tools-Diagnostic',
    '10140-System Tools-Bus Traffic Logger',
    '20110-Safety Systems-Alarm Enunciator',
    '20128-Safety Systems-NMEA 2000 Security Device',
    '20130-Safety Systems-Emergency Position Indicating Radio Beacon (EPIRB)',
    '20135-Safety Systems-Man Overboard',
    '20140-Safety Systems-Voyage Data Recorder',
    '20150-Safety Systems-Camera',
    '25130-Inter/Intranetwork Device-PC Gateway',
    '25131-Inter/Intranetwork Device-NMEA 2000 to Analog Gateway',
    '25132-Inter/Intranetwork Device-Analog to NMEA 2000 Gateway',
    '25133-Inter/Intranetwork Device-NMEA 2000 to Serial Gateway',
    '25135-Inter/Intranetwork Device-NMEA 0183 Gateway',
    '25136-Inter/Intranetwork Device-NMEA Network Gateway',
    '25137-Inter/Intranetwork Device-NMEA 2000 Wireless Gateway',
    '25138-Inter/Intranetwork Device-Digital to NMEA 2000 Gateway',
    '25139-Inter/Intranetwork Device-Modbus to NMEA 2000',
    '25140-Inter/Intranetwork Device-Router',
    '25150-Inter/Intranetwork Device-Bridge',
    '25160-Inter/Intranetwork Device-Repeater',
    '30130-Electrical Distribution-Binary Event Monitor',
    '30140-Electrical Distribution-Load Controller',
    '30141-Electrical Distribution-AC/DC Input',
    '30150-Electrical Distribution-Function Controller',
    '35140-Electrical Generation-Engine',
    '35141-Electrical Generation-DC Generator/Alternator',
    '35142-Electrical Generation-Solar Panel (Solar Array)',
    '35143-Electrical Generation-Wind Generator (DC)',
    '35144-Electrical Generation-Fuel Cell',
    '35145-Electrical Generation-Network Power Supply',
    '35151-Electrical Generation-AC Generator',
    '35152-Electrical Generation-AC Bus',
    '35153-Electrical Generation-AC Mains (Utility/Shore)',
    '35154-Electrical Generation-AC Output',
    '35160-Electrical Generation-Power Converter Battery Charger',
    '35161-Electrical Generation-Power Converter Battery Charger+Inverter',
    '35162-Electrical Generation-Power Converter Inverter',
    '35163-Electrical Generation-Power Converter DC',
    '35170-Electrical Generation-Battery',
    '35180-Electrical Generation-Engine Gateway',
    '35201-Electrical Generation-Filters',
    '40130-Steering and Control Surfaces-Follow up Controller',
    '40140-Steering and Control Surfaces-Mode Controller',
    '40150-Steering and Control Surfaces-Autopilot',
    '40155-Steering and Control Surfaces-Rudder',
    '40160-Steering and Control Surfaces-Heading Sensors',
    '40170-Steering and Control Surfaces-Trim (Tabs)/Interceptors',
    '40180-Steering and Control Surfaces-Attitude (Pitch',
    '40190-Steering and Control Surfaces-Transom Lift Sensor',
    '40195-Steering and Control Surfaces-Transom Lift Controller',
    '50130-Propulsion-Engineroom Monitoring',
    '50140-Propulsion-Engine',
    '50141-Propulsion-DC Generator/Alternator',
    '50145-Propulsion-Thruster Engine',
    '50147-Propulsion-Thruster Motor',
    '50150-Propulsion-Engine Controller',
    '50151-Propulsion-AC Generator',
    '50155-Propulsion-Motor',
    '50160-Propulsion-Engine Gateway',
    '50165-Propulsion-Transmission',
    '50170-Propulsion-Throttle/Shift Control',
    '50180-Propulsion-Actuator',
    '50190-Propulsion-Gauge Interface',
    '50200-Propulsion-Gauge Large',
    '50201-Propulsion-Filters',
    '50210-Propulsion-Gauge Small',
    '60130-Navigation-Bottom Depth',
    '60134-Navigation-Speed / Temp',
    '60135-Navigation-Bottom Depth/Speed',
    '60136-Navigation-Depth / Speed / Temp',
    '60140-Navigation-Ownship Attitude',
    '60145-Navigation-Ownship Position (GNSS)',
    '60150-Navigation-Ownship Position (Loran C)',
    '60155-Navigation-Speed',
    '60160-Navigation-Turn Rate Indicator',
    '60170-Navigation-Integrated Navigation',
    '60175-Navigation-Integrated Navigation System',
    '60190-Navigation-Navigation Management',
    '60195-Navigation-Automatic Identification System',
    '60196-Navigation-AIS Shore based systems',
    '60197-Navigation-AIS Airborne',
    '60200-Navigation-Radar',
    '60201-Navigation-Infrared Imaging',
    '60205-Navigation-ECDIS',
    '60210-Navigation-ECS',
    '60220-Navigation-Direction Finder',
    '60230-Navigation-Voyage Status',
    '65130-AIS as defined in International Standards-Class A Mobile',
    '65132-AIS as defined in International Standards-Class B SO (Self Organizing)',
    '65134-AIS as defined in International Standards-Class B CS (Carrier Sense)',
    '65136-AIS as defined in International Standards-SAR Airborne',
    '65140-AIS as defined in International Standards-AIS Man Overboard (MOB)',
    '65142-AIS as defined in International Standards-AIS Personal Locator Beacon (PLB)',
    '65144-AIS as defined in International Standards-AIS Search and Rescue Transponder (SART)',
    '65146-AIS as defined in International Standards-AIS EPIRB',
    '65150-AIS as defined in International Standards-Aid to Navigation (AtoN) Type 1',
    '65152-AIS as defined in International Standards-Aid to Navigation (AtoN) Type 2',
    '65154-AIS as defined in International Standards-Aid to Navigation (AtoN) Type 3',
    '65156-AIS as defined in International Standards-Mobile Aid to Navigation (AtoN)',
    '65160-AIS as defined in International Standards-AIS Base Station',
    '65162-AIS as defined in International Standards-AIS Repeater',
    '65164-AIS as defined in International Standards-Limited Base Station [Reserved for Future Use]',
    '65170-AIS as defined in International Standards-AIS VHF Data Exchange System (VDES) ASM [Reservd]',
    '66130-AIS not fully defined by International Standards-AIS Receive Only',
    '66140-AIS not fully defined by International Standards-Transmits Only Specific Information',
    '70130-Communication-EPIRB',
    '70140-Communication-AIS',
    '70150-Communication-DSC',
    '70160-Communication-Data Receiver/Transceiver',
    '70170-Communication-Satellite',
    '70171-Communication-Cellular Data Network',
    '70180-Communication-Radiotelephone (MF/HF)',
    '70190-Communication-Radiotelephone',
    '70192-Communication-Remote Radio MKD',
    '75130-Sensor Communication Interface-Temperature',
    '75140-Sensor Communication Interface-Pressure',
    '75150-Sensor Communication Interface-Fluid Level',
    '75160-Sensor Communication Interface-Flow',
    '75170-Sensor Communication Interface-Humidity',
    '80130-Instrumentation/General Systems-Time/Date Systems',
    '80140-Instrumentation/General Systems-VDR',
    '80150-Instrumentation/General Systems-Integrated Instrumentation',
    '80160-Instrumentation/General Systems-General Purpose Displays',
    '80170-Instrumentation/General Systems-General Sensor Box',
    '80180-Instrumentation/General Systems-Weather Instruments',
    '80190-Instrumentation/General Systems-Transducer/General',
    '80200-Instrumentation/General Systems-NMEA 0183 Converter',
    '85130-External Environment-Atmospheric',
    '85160-External Environment-Aquatic',
    '90130-Internal Environment-HVAC',
    '100110-Deck- Cargo and Fishing Equipment Systems',
    '100130-Deck- Cargo and Fishing Equipment Systems',
    '100140-Deck- Cargo and Fishing Equipment Systems',
    '110130-Human Interface Device-Button Interface',
    '110135-Human Interface Device-Switch Interface',
    '110140-Human Interface Device-Analog Interface',
    '120130-Display-Display',
    '120135-Display-Display Interface',
    '120140-Display-Alarm Enunciator',
    '125130-Entertainment-Multimedia Player',
    '125140-Entertainment-Multimedia Controller',
    '126130-Lighting-Lighting Controller'
];

const manData = [
    "78-FW Murphy/Enovation Controls ",
    "80-Twin Disc ",
    "85-Kohler Power Systems ",
    "88-Hemisphere GNSS Inc. ",
    "116-BEP Marine ",
    "135-Airmar ",
    "137-Maretron ",
    "140-Lowrance ",
    "144-Mercury Marine ",
    "147-Nautibus Electronic GmbH ",
    "148-Blue Water Data ",
    "154-Westerbeke ",
    "161-Offshore Systems (UK) Ltd. ",
    "163-Evinrude/BRP Bombardier ",
    "165-CPAC Systems AB ",
    "168-Xantrex Technology Inc. ",
    "172-Yanmar Marine ",
    "174-Volvo Penta ",
    "176-Moritz Aerospace ",
    "185-Beede Instruments ",
    "192-Floscan Instrument Co. Inc. ",
    "193-Nobletec ",
    "198-Mystic Valley Communications ",
    "199-Actia Corporation ",
    "201-DisenosY Technolgia ",
    "211-Digital Switching Systems ",
    "215-Aetna Engineering/Fireboy/Xintex ",
    "224-EMMI NETWORK S.L. ",
    "228-ZF Marine Electronics ",
    "229-Garmin ",
    "233-Yacht Monitoring Solutions ",
    "235-Sailormade Marine Telmetry/Tetra Technology LTD ",
    "243-Eride ",
    "257-Honda Motor Company LTD ",
    "272-Groco ",
    "273-Actisense ",
    "274-Amphenol LTW Technology ",
    "275-Navico ",
    "283-Hamilton Jet ",
    "285-Sea Recovery ",
    "286-Coelmo SRL Italy ",
    "295-BEP Marine ",
    "304-Empirebus ",
    "305-NovAtel ",
    "306-Sleipner Motor AS ",
    "307-MBW Technologies (formerly MAS) ",
    "315-ICOM ",
    "328-Qwerty ",
    "329-Dief ",
    "341-Böning Automationstechnologie GmbH & Co. KG ",
    "345-Korean Maritime University ",
    "351-Thrane and Thrane ",
    "355-Mastervolt ",
    "356-Fischer Panda Generators ",
    "358-Victron Energy ",
    "370-Rolls Royce Marine ",
    "373-Electronic Design ",
    "374-Nothern Lights ",
    "378-Glendinning ",
    "381-B & G  ",
    "384-Camano Light ",
    "385-GeoNav ",
    "385-Johnson Outdoors Marine Electronics Inc    Geonav ",
    "394-Capi 2 ",
    "396-Beyond Measure ",
    "400-Livorsi Marine ",
    "404-ComNav ",
    "419-Fusion ",
    "421-Standard Horizon ",
    "422-True Heading AB ",
    "426-Egersund Marine Electronics AS ",
    "427-em-trak Marine Electronics ",
    "431-Tohatsu Co, JP ",
    "437-Digital Yacht ",
    "438-Comar Systems Limited ",
    "440-Cummins ",
    "443-VDO (aka Continental-Corporation) ",
    "451-Parker Hannnifin aka Village Marine Tech ",
    "459-Alltek Marine ",
    "460-SAN GIORGIO S.E.I.N ",
    "466-VeeThree ",
    "467-Humminbird Marine Electronics ",
    "470-SI-TEX Marine Electronics ",
    "471-Sea Cross Marine AB ",
    "475-GME aka Standard Communications Pty LTD ",
    "476-Humminbird Marine Electronics ",
    "478-Ocean Sat BV ",
    "481-Chetco Digitial Instruments ",
    "493-Watcheye ",
    "499-Lcj Capteurs ",
    "502-Attwood Marine ",
    "503-Naviop S.R.L. ",
    "504-Vesper Marine Ltd ",
    "510-Marinesoft Co. LTD ",
    "517-NoLand Engineering ",
    "518-Transas USA ",
    "529-National Instruments Korea ",
    "530-National Marine Electronics Association ",
    "532-Onwa Marine ",
    "540-Webasto  ",
    "571-Marinecraft (South Korea) ",
    "573-McMurdo Group aka Orolia LTD ",
    "578-Advansea ",
    "579-KVH ",
    "580-San Jose Technology ",
    "583-Yacht Control ",
    "586-Suzuki Motor Corporation ",
    "591-USCG ",
    "595-Ship Module aka Customware ",
    "600-Aquatic AV ",
    "605-Aventics GmbH ",
    "606-Intellian ",
    "612-SamwonIT ",
    "614-Arlt Tecnologies ",
    "637-Bavaria Yacts ",
    "641-Diverse Yacht Services ",
    "644-KUS ",
    "644-Wema U.S.A dba KUS ",
    "645-Garmin ",
    "658-Shenzhen Jiuzhou Himunication ",
    "688-Rockford Corp ",
    "704-JL Audio ",
    "715-Autonnic ",
    "717-Yacht Devices ",
    "734-REAP Systems ",
    "735-AEM Power ",
    "739-LxNav ",
    "743-DaeMyung ",
    "744-Woosung ",
    "773-Clarion US ",
    "776-HMI Systems ",
    "777-Ocean Signal ",
    "778-Seekeeper ",
    "781-Poly Planar ",
    "785-Fischer Panda DE ",
    "795-Broyda Industries ",
    "796-Canadian Automotive ",
    "797-Tides Marine ",
    "798-Lumishore ",
    "799-Still Water Designs and Audto ",
    "802-BJ Technologies (Beneteau) ",
    "803-Gill Sensors ",
    "811-Blue Water Desalination ",
    "815-FLIR ",
    "824-Undheim Systems ",
    "838-TeamSurv ",
    "844-Fell Marine ",
    "847-Oceanvolt ",
    "862-Prospec ",
    "868-Data Panel Corp ",
    "890-L3 Technologies ",
    "894-Rhodan Marine Systems ",
    "896-Nexfour Solutions ",
    "905-ASA Electronics ",
    "909-Marines Co (South Korea0 ",
    "911-Nautic-on ",
    "929-Power Pole  ",
    "930-Ecotronix ",
    "944-Zontisa Marine ",
    "962-Timbolier Industries ",
    "968-Cox Powertrain ",
    "969-Blue Sea ",
    "981-Kobelt Manufacturing Co. Ltd ",
    "1008-Lintest SmartBoat ",
    "1011-Soundmax ",
    "1020-Onyx Marine Automation s.r.l ",
    "1021-Entratech ",
    "1022-ITC Inc. ",
    "1023-PEAK-System Technik GmbH ",
    "1029-The Marine Guardian LLC ",
    "1047-Sonic Corporation ",
    "1051-ProNav ",
    "1053-Vetus Maxwell INC. ",
    "1056-Lithium Pros ",
    "1059-Boatrax ",
    "1062-ComNav ",
    "1065-CALYPSO Instruments ",
    "1066-Spot Zero Water ",
    "1070-Quick-teck Electronics Ltd ",
    "1075-Uniden America ",
    "1083-Nauticoncept ",
    "1084-Shadow-Caster LED lighting LLC ",
    "1085-Wet Sounds, LLC  ",
    "1088-E-T-A Circuit Breakers ",
    "1092-Scheiber ",
    "1100-Smart Yachts International Limited ",
    "1850-Teleflex Marine (SeaStar Solutions) ",
    "1851-Raymarine ",
    "1852-Navionics ",
    "1853-Japan Radio Co ",
    "1854-Northstar Technologies ",
    "1855-Furuno ",
    "1856-Trimble ",
    "1857-Simrad ",
    "1858-Litton ",
    "1859-Kvasar AB ",
    "1860-MMP ",
    "1861-Vector Cantech ",
    "1862-Yamaha Marine ",
    "1863-Faria Instruments ",
    "917-Sentinel ",
    "1114-Bobs Machine "
];

const defaultTiming = [ // 0's mean no limit, can be used as 1
    0,10,0,100,0,0,100,10,600,0,0,0,2,1,1,1,1,10,10,1,5,1,10,10,
    0,15,0,0,15,15,25,15,15,15,15,0,0,0,0,15,15,15,15,15,15,15,15,15,
    2,5,0,5,
    10,10,10,10,1,10,0,
    5,5,5,2,
    1,2,1,1,10,0,0,0,0,0,
    100,0,10,10,0,10,10,0,0,10,10,0,10,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,10,
    10,0,0,0,0,0,0,0,0,0,0,0,0,0,1,5,5,20,20,20,0,0,10,10,10,10,10,10,25,5,0,0,0,0,0,2,10,2,0,0,0,0,0,0,1
]; // *100msec