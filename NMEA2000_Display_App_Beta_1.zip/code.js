const LoggingEvent = "LOG_EVENT";
const MsgEvent = "MESSAGE_EVENT";
const MsgNumEvent = "MESSAGE_NUMBER_UPDATE_EVENT";
// message responses
const ResetCheckMsg = "$PDGY,TEXT,Digital_Yacht_iKonvert";
// message prefixes
const RxListMsgPrefix = "$PDGY,RX_LIST,";
const TxListMsgPrefix = "$PDGY,TX_LIST,";
const N2ModeMsgPrefix = "$PDGY,N2NET_MODE,";
const N2InitMsgPrefix = "$PDGY,N2NET_INIT,";
// command messages
const CommandModeOnMsg = "$PDGY,CMD";
const CommandModeOffMsg = "$PDGY,EXIT";
const OfflineMsg = "$PDGY,N2NET_OFFLINE";
const N2ResetMsg = "$PDGY,N2NET_RESET,";
const ResetBlacklistMsg = "$PDGY,RESET_BLACKLIST";
const N2NetNameMsg = "$PDGY,GET_N2NET_NAME";
const N2InitAllMsg = "$PDGY,N2NET_INIT,ALL";
const Mode15Msg = `${N2ModeMsgPrefix}15`;
// util
const braudRates = [
    230400,
    4800,
    38400,
    115200,
    // 230400,
]; // 15, 0, 1, 14
const MaxStringBufferSize = 999999;
const ChangeTestFallbackTimer = 15000; // in ms
const timeToTest = 2500; // 2.5s
const jsCrLf = "\r\n";

let port = null;
let writer = null;
let reader = null;
let readableStream = null; // store pipeline promise
let isReading = false;
let isScanning = false;
let canSendFallbackMsg = false;
let verbose = false; // debug
let readLoopRunning = false;
let currentMode = null;
let currentBaud = null;
let timerIteration = 0;
let messagesBuffer = "";

function doLog(message, level = 'log') {
    document.dispatchEvent(new CustomEvent(LoggingEvent, {
        detail: {
            message: message,
            level: level,
            timestamp: new Date().toISOString(),
        }
    }));
    // debug
    if (verbose) handleVerboseLog(message, new Date().getTime(), level);
}

function handleVerboseLog(message, time, level = 'log') {
    message = `Verbose @ ${time.toString().slice(-7)} ↓↓↓\n${message}`;
    switch (level[0].toLowerCase()){
        case 'i': console.info(message); break;
        case 'w': console.warn(message); break;
        case 'e': console.error(message); break;
        default: console.log(message); break; // includes l
    }
}

async function disconnectReader() {
    try {
        doLog('Closing reader...');

        if (reader) {
            doLog('Stopping reader...');
            await reader.cancel();
            doLog('Releasing reader...');
            reader.releaseLock();
            doLog('Reader stopped safely.');
            reader = null;
        } else {
            doLog('No reader to close.');
        }

        if (readableStream) {
            doLog('Waiting for pipeline to close...');

            if (readableStream && typeof readableStream.closed === 'object' && typeof readableStream.closed.then === 'function') {
                await readableStream.closed
                    .then(() => {
                        doLog('Pipeline closed successfully.');
                    })
                    .catch(err => {
                        doLog(`Pipeline closed (expected cancellation): ${err.message}`);
                    });
            } else {
                doLog('Invalid readableStream or it does not have a .closed property.');
            }

            readableStream = null;
            doLog('Pipeline reference wiped.');
        }

    } catch (err) {
        doLog(`Error during disconnecting reader or pipeline: ${err.message}`, 'error');
        reader = null;
        readableStream = null;
    }
}

async function disconnectWriter() {
    try {
        doLog('closing writer...')
        if (writer) {
            await writer.ready; // wait for pending writes
            await writer.releaseLock();
            writer = null;
            doLog('writer closed.');
        }
    } catch (err) {
        doLog(`error closing writer: ${err.message}`, 'error');
        writer = null;
    }
}

async function disconnectPort(wipePort = true) {
    try {
        doLog('Closing port...');

        if (port?.readable && port?.writable) {
            if (port.readable.locked || port.writable.locked) {
                const waitTime = 500;
                doLog(`Port streams still locked, waiting ${waitTime}ms...`, 'warn');

                await waitForStreamsToUnlock(port);

                doLog('Streams unlocked.');
            }

            await port.close();
            currentBaud = null;
            currentMode = null;
            doLog('Port closed.');
        }
    } catch (err) {
        doLog(`Error closing port: ${err.message}`, 'error');
    } finally {
        if (wipePort) {
            port = null;
            doLog('Port wiped.');
        }
    }
}

async function waitForStreamsToUnlock(port) {
    while (port.readable.locked || port.writable.locked) {
        try {
            if (port.readable.locked) {
                doLog('Cancelling reader...');
                await port.readable.getReader().cancel();
                doLog('Reader cancelled.');
            }
        } catch (e) {
            doLog('Forcing reader to cancel failed', 'warn');
        }

        try {
            if (port.writable.locked) {
                doLog('Releasing writer lock...');
                port.writable.getWriter().releaseLock();
                doLog('Writer lock released.');
            }
        } catch (e) {
            doLog('Forcing writer to release its lock failed', 'warn');
        }

        await new Promise(resolve => setTimeout(resolve, 100));
    }
}

async function disconnectAll(wipePort = true) {
    await disconnectReader();
    await disconnectWriter();
    await disconnectPort(wipePort);
}

function constructChangeMsg(newBraudRate) {
    let modeNum;
    switch (newBraudRate) {
        case 4800: modeNum = 0; break;
        case 38400: modeNum = 1; break;
        case 115200: modeNum = 14; break;
        // set newBraudRate cus error fixing
        default: case 230400: modeNum = 15; newBraudRate = 230400; break;
    }
    currentMode = modeNum;
    return { msg: `${N2ModeMsgPrefix}${modeNum}`, nbr: newBraudRate, mode: modeNum };
}

async function doMsgSend(msg, doCrLfCheck = true) {
    doLog(`sending message: ${msg}`);
    if(doCrLfCheck && msg.slice(-2) !== jsCrLf) msg += jsCrLf; // make sure we have [CR][LF] at the end of our msg
    const textEncoder = new TextEncoder();
    const encodedMsg = textEncoder.encode(msg);
    if (writer == undefined) writer = port.writable.getWriter();
    await writer.write(encodedMsg);
    doLog(`message sent!`);
    return true;
}

async function sendSetupCommands(modeMsg = null, canDoModeChange = true) {
    
    if(canDoModeChange && modeMsg != Mode15Msg) {
        // TODO: CHANGE TO 230400
        const splitMsg = modeMsg.split(",");
        const oldMode = splitMsg[splitMsg.length -1];
        doLog(`doing ${Mode15Msg} on ${oldMode}`);
        doLog(currentBaudRate);
        await entrypoint_changeBraudRate(currentBaudRate, 230400);

        console.log("pre port change")
        await connectToPort(230400);
        console.log("DONE!!!")

        modeMsg = Mode15Msg;
    }

    // console.log("==============================================")
    // console.log(port)
    // console.log(port.baudRate)
    await doMsgSend(N2InitAllMsg);
    if (modeMsg) await doMsgSend(modeMsg);
    await doMsgSend(CommandModeOffMsg);
    // await doMsgSend("$PDGY,BASE64,OFF,");

    // const smm = modeMsg.split(",");
    // return smm[smm.length -1];
}

async function connectToPort(baudRate) {

    await disconnectAll(false);

    if (port == null) {
        port = await navigator.serial.requestPort();
        doLog("user has selected port!");
    } else console.warn("already connected to port"); // doLog("already connected to port", 'warn');

    try {
        doLog("opening new port connection...");
        await port.open({ baudRate: baudRate });
        currentBaud = baudRate;
        console.log(`new baudRate: ${baudRate}`);
    } catch {
        console.warn("already connected to port");
        doLog(`port already open @${currentBaud}, if this is unexpected, disconnect from it`, 'warn');
    }
}

async function connectToPortAndSetUpReader(baudRate) {
    if (port && port.readable !== null && port.writable !== null) {
        doLog("disconnecting old port connections...");
        await disconnectAll(false);
    }
    await connectToPort(baudRate);
    setupReader();
}

function setupReader() {
    if (port && reader == null) {

        const decoder = new TextDecoderStream("utf-8");

        if (!port.readable.locked) {
            readableStream = port.readable.pipeTo(decoder.writable, {fatal : false});
        }

        reader = decoder.readable.getReader();
    }
}

function handleChangeSuccessOutput(oldBraudRate, newBraudRate, endState) {
    let wasSuccess = false;
    switch (endState) {
        case -1: doLog("change done via reset confimation :)"); wasSuccess = true; break; // the only good outcome...
        case -2: doLog("change done via timeout...", 'warn'); break;
        case -3: doLog("change done via reader completion...", 'warn'); break;
        case -4: doLog("change done via read error...", 'warn'); break;
        default: doLog("idk how we did the change...", 'warn'); break;
    }
    if (wasSuccess) doLog(`baud rate has changed from ${oldBraudRate} to ${newBraudRate}`);
    else doLog(`baud rate SHOULD have changed from ${oldBraudRate} to ${newBraudRate}`);
    return wasSuccess;
}

function handleDetectOfResetPgnMsg(allMsg, newMsg) {

    let found = false;
    allMsg += newMsg;

    // keep only recent data if buffer gets too large
    if (allMsg.length > MaxStringBufferSize) {
        doLog("Buffer size exceeded, trimming...", 'warn');
        allMsg = allMsg.slice(-MaxStringBufferSize / 2);
    }

    if (allMsg.length > ResetCheckMsg.length && allMsg.includes(ResetCheckMsg)) {
        found = true;
    }

    return { allMsg: allMsg, found: found }
}

async function handlePortScanTest(passedBaudRate) {
    let resCount = 0;
    let running = true;

    await connectToPortAndSetUpReader(passedBaudRate);

    const testStartTime = new Date().getTime();
    while (running) {
        try {
            const { value, done } = await reader.read();
            if (done) {
                doLog('stream closed by device');
                running = false;
                reader.releaseLock();
            } else if (value) {
                doLog(`recieved: ${value}`);
                if (value.includes('$') || value.includes('!')) resCount++; // simple test, may need to be improved <<<<<<<<<<<<<<<<<<<<<<
                running = testStartTime + timeToTest > new Date().getTime();
            }
        } catch (err) {
            doLog(`read error (possibly framing error): ${err.message}`, 'error');
            running = false; // assume wrong braud
        }
    }

    return resCount;
}

function handleCleanPgnTextOutput(textArray) {
    let popped = textArray;
    if (textArray.length) {
        popped = textArray.pop(); // get last entry
        textArray.forEach(text => {
            doLog(`recieved: $${text}`) // keep extra $
        });
    }
    return popped;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

async function entrypoint_changeBraudRate(oldBraudRate, newBraudRate, forceModeNum = null) {
    // setup
    let wasSuccess = false;
    let allMessages = "";
    let constructedChangeMessage = `${N2ModeMsgPrefix}${forceModeNum}`
    if(forceModeNum !== null) {
        const ccmRes = constructChangeMsg(newBraudRate);
        newBraudRate = ccmRes.nbr;
        constructedChangeMessage = ccmRes.msg
    }
    
    setupReader();

    try {
        // await connectToPortAndSetUpReader(oldBraudRate);

        // send offline msg
        await doMsgSend(OfflineMsg);

        // wait for deivce to reset
        doLog("listening for reset confimation...")
        let iteration = 0
        let readRunStart = new Date().getTime();
        do {
            console.log(`do-while iteration: ${iteration++}`)
            if (readRunStart + ChangeTestFallbackTimer < new Date().getTime()) {
                readRunStart = -2;
            }
            else {
                try {
                    doLog(`pre-await @ ${new Date()}`)
                    const { value, done } = await reader.read();
                    doLog(`post-await @ ${new Date()}`)
                    if (done) {
                        readRunStart = -3;
                        reader.releaseLock();
                    } else {
                        const hpmRes = handleDetectOfResetPgnMsg(allMessages, value)
                        if (hpmRes.found) readRunStart = -1;
                        else allMessages = hpmRes.allMsg;
                    }
                } catch (e) {
                    console.warn(e)
                    if(iteration > 5) readRunStart = -4; // exit on read error
                }
            }
        } while (readRunStart > 0);

        console.log(`readRunStart: ${readRunStart}`);

        // change mode
        await doMsgSend(constructedChangeMessage);
        // done msg
        wasSuccess = handleChangeSuccessOutput(oldBraudRate, newBraudRate, readRunStart);
        // if (wasSuccess) await 

    } catch (err) {
        doLog(`error changing rate: ${err.message}`, 'error');
    }

    return wasSuccess;
}

async function entrypoint_doScan(doCleanup = true) {
    let testResults = [];
    let recommendedBraud = { responses: 0 };

    doLog("prompting user...")
    port = await navigator.serial.requestPort();
    doLog(`user has selected a port!`);
    isScanning = true;
    handleStartupCountdown(true);

    for (const index in braudRates) {
        const rate = braudRates[index];
        let scanRes = 0;

        doLog(`\n---------------------------------------------------------`);
        doLog(`testing: ${rate}`);

        try {
            scanRes = await handlePortScanTest(rate); // do test
            doLog(`${rate} completed successfully with ${scanRes} valid responses`);
        } catch (err) {
            doLog(`error occurred when scanning ${rate}: ${err.message}`, 'error');
            scanRes = 0;
        } finally {

            await disconnectReader();
            await disconnectPort(false);

            // add small delay to ensure port is 100% closed before next test
            await new Promise(resolve => setTimeout(resolve, 100));
        }

        testResults.push({
            braudRate: rate,
            responses: scanRes,
        });
    }

    isScanning = false;

    // cleanup
    if (doCleanup) await disconnectAll();

    // result output
    doLog(" ");
    doLog("=======================================");
    doLog("SCAN RESULTS BELOW: ===================");
    doLog("=======================================");
    doLog(" ");

    testResults.forEach(result => {
        doLog(`${result.braudRate} returned ${result.responses} valid responses`);
        if (result.responses > recommendedBraud.responses) recommendedBraud = result;
    })

    if (recommendedBraud.braudRate) doLog(`\n${recommendedBraud.braudRate} returned the most valid responses (${recommendedBraud.responses})`);
    else doLog("\nno results...");

    doLog(" ");
    doLog("=======================================");
    doLog("TEST COMPLETE :) ======================");
    doLog("=======================================");

    return recommendedBraud;
}

async function entrypoint_doReadLoop() {
    canSendFallbackMsg = true;
    messagesBuffer = "";
    const MAX_BUFFER_SIZE = 10000; // Adjust based on needs

    try {

        setupReader();
        readLoopRunning = true;

        while (readLoopRunning) {

            let value, done;
            try {
                ({ value, done } = await reader.read());
            } catch (err) {
                console.error("reader.read() threw:", err);
                throw err;  // Optional: rethrow to go to outer catch
            }

            if (value.includes('\uFFFD')) {
                console.warn("Corrupted data received");
                console.log(value);
            }

            if (done) {
                doLog('stream closed by device');
                readLoopRunning = false;
                reader.releaseLock();
            } else if (value) {

                messagesBuffer += value;

                if(canSendFallbackMsg && messagesBuffer.includes("PDGY,000000,,,,")){
                    // brute force fallback for if we fail to send our connection msg at the right time
                    console.warn("used fallback setup method");
                    sendSetupCommands(null, false);
                    canSendFallbackMsg = false;
                }

                // rolling buffer: keep only recent data
                if (messagesBuffer.length > MAX_BUFFER_SIZE) {
                    // find the last complete message boundary
                    const lastMsgGapInstance = messagesBuffer.lastIndexOf(jsCrLf, MAX_BUFFER_SIZE / 2);
                    if (lastMsgGapInstance > 0) {
                        messagesBuffer = messagesBuffer.substring(lastMsgGapInstance);
                    } else {
                        // fallback: just truncate to half size
                        messagesBuffer = messagesBuffer.substring(MAX_BUFFER_SIZE / 2);
                    }
                }

                // debug
                // if (verbose) handleVerboseLog(`inbound msg:\n${value}`, new Date().getTime(), 'info');
                
                // send message as event
                document.dispatchEvent(new CustomEvent(MsgEvent, {
                    detail: { message: value }
                }));

                // handle msg number stuff
                const splitMsgs = messagesBuffer.split("$");
                if (splitMsgs.length > 2) {
                    const secondLastMsg = splitMsgs[splitMsgs.length - 2];
                    const slmSplit = secondLastMsg.split(',');
                    if(slmSplit[0] == "PDGY" && !isNaN(slmSplit[1])) {
                        const lastMsgNum = Number(slmSplit[5]);
                        document.dispatchEvent(new CustomEvent(MsgNumEvent, {
                            detail: { currentMsgNum: lastMsgNum + 1 }
                        }));
                    }
                }
            }
        }
    } catch (err) {
        doLog(`error during read operation: ${err.message}`, 'error');
        await disconnectAll(false);
    }
}

async function entrypoint_doMessageWrite(passedBaudRate, pgnString) {
    try {
        // request the port if not already open
        await connectToPort(passedBaudRate)
        await doMsgSend(pgnString);
    } catch (err) {
        doLog(`Error sending PGN: ${err.message}`, 'error');
    }
}

async function entrypoint_setupForComms(modeNum, passedRxList = [], passedTxList = []) {
    // await doMsgSend(OfflineMsg);

    doLog(`sending RX list!`);
    await doMsgSend(RxListMsgPrefix + passedRxList.join(','));
    doLog(`sending TX list!`);
    await doMsgSend(TxListMsgPrefix + passedTxList.join(','));
    doLog(`sending Init msg!`);
    await doMsgSend(N2InitMsgPrefix + modeNum);
}

async function entrypoint_closeConnection() {
    await disconnectAll()
}

function loadFile() {
    return new Promise((resolve, reject) => {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.json,.txt';
        input.onchange = function (e) {
            const file = e.target.files[0];
            if (!file) {
                reject(new Error('No file selected'));
                return;
            }
            const fileRead = new FileReader();
            fileRead.onload = function (e) {
                try {
                    const array = JSON.parse(e.target.result);
                    resolve(array);
                } catch {
                    const array = e.target.result.split('\n').filter(line => line.trim());
                    resolve(array);
                }
            };
            fileRead.onerror = () => reject(new Error('Failed to read file'));
            fileRead.readAsText(file);
        };
        input.click();
    });
}

function saveFile(data, filename = "dy_data.json") {
    const text = Array.isArray(data) ? JSON.stringify(data, null, 2) : data.toString();
    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
}

function handleStartupCountdown(firstIteration = false) {
    if(firstIteration) timerIteration = 0;
    const elem = document?.getElementById("startupStatusOutput");
    if(elem && isScanning) {

        const aSecond = 1000;
        const totalTimeToTestInSecs = parseInt( timeToTest * braudRates.length / aSecond );
        // const testTimeRemaining = parseInt( totalTimeToTestInSecs - timerIteration );
        const testTimeRemaining = timerIteration; // was a count down now a count up
        
        let newElemClass = "positiveStatus";
        let newElemOutput = `Scanning for baud rate, this has taken ${testTimeRemaining} seconds...`;
        // let doNextIteration = testTimeRemaining >= 0;
        // if (!doNextIteration) {
        //     newElemClass = "questionStatus";
        //     newElemOutput = `Scan has taken longer than ${totalTimeToTestInSecs}, it may have failed.`
        // }

        elem.classList = `statusItem ${newElemClass}`;
        elem.innerHTML = newElemOutput;

        timerIteration++;
        // if (doNextIteration) setTimeout(handleStartupCountdown, aSecond);
        setTimeout(handleStartupCountdown, aSecond);
    }
}

function doStartupChecks() {
    if (navigator?.serial?.requestPort) { // good outcome
        console.info('user is running a compatible browser :)');
        document.getElementById("startupModal").style = "display: block;";
    } else { // bad outcome
        console.warn('user is not running a compatible browser :(');
        alert("Error: incorrect browser type, please use Chromium, Edge or Opera");
        document.getElementById("errorModal").style = "display: block;";
    }

    // 100 ms delay to allow some css to load
    if(window.innerHeight > window.innerWidth) setTimeout(alert("This page is best viewed in landscape mode."), 100);
}

function generateTimeCellContents(timeValue) {
    // time stuff
    const msgTimeNum = String(timeValue).split('.')[0];
    const tobSecs = msgTimeNum % 60;
    const tobMinsScaled = (msgTimeNum - tobSecs) % 3600;
    const tobMins = tobMinsScaled / 60;
    const tobHoursScaled = (msgTimeNum - (tobSecs + tobMinsScaled));
    const tobHours = tobHoursScaled / 3600;
    const timeFrontend = `${String(tobHours).padStart(2,'0')}:${String(tobMins).padStart(2,'0')}:${String(tobSecs).padStart(2,'0')}`
    // const timeFrontend = `${tobHours}:${tobMins < 10 ? '0' + tobMins : tobMins}:${tobSecs < 10 ? '0' + tobSecs : tobSecs}`;
    return timeFrontend;
}